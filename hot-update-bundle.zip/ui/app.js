'use strict';

const callbacks = new Map();
let requestNumber = 0;
window.NativeCallbacks = {
  resolve(id, value) { callbacks.get(id)?.resolve(value); callbacks.delete(id); },
  reject(id, message) { callbacks.get(id)?.reject(new Error(message)); callbacks.delete(id); }
};
function api(action, args = {}) {
  return new Promise((resolve, reject) => {
    const id = (window.HotRuntime?.bootId || 'legacy') + ':' + (++requestNumber);
    callbacks.set(id, { resolve, reject });
    try { AndroidHost.request(id, action, JSON.stringify(args)); }
    catch (error) { callbacks.delete(id); reject(error); }
  });
}

function formatBytes(bytes) {
  const value = Number(bytes) || 0;
  if (value >= 1073741824) return (value / 1073741824).toFixed(1) + ' GB';
  return Math.max(0, Math.round(value / 1048576)) + ' MB';
}
function downloadInfo(id, episode) {
  const key = `${id}:${episode}`;
  return asArray(state.downloads?.items).find(item => item.key === key) || null;
}
function downloadBadge(info) {
  if (!info) return '⬇';
  if (info.status === 'done') return '✓';
  if (info.status === 'downloading') return '…';
  if (info.status === 'queued') return '·';
  if (info.status === 'error') return '!';
  return '⏸';
}
function refreshDownloadBadges() {
  const detail = state.detail;
  if (!detail) return;
  content.querySelectorAll('[data-download-ep]').forEach(node => {
    const info = downloadInfo(detail.id, Number(node.dataset.downloadEp));
    node.textContent = downloadBadge(info);
    node.classList.toggle('has', Boolean(info && info.status === 'done'));
    node.classList.toggle('busy', Boolean(info && (info.status === 'downloading' || info.status === 'queued')));
  });
}
window.hgDownloadProgress = data => {
  if (!data || !Array.isArray(data.items)) return;
  state.downloads = data;
  const free = Number(data.free) || 0;
  const warnBelow = Number(data.warnBelow) || 0;
  if (free > 0 && warnBelow > 0 && free < warnBelow) {
    if (!state.lowSpaceNotified) {
      state.lowSpaceNotified = true;
      toast(`手机剩余存储不足（${formatBytes(free)}），下载可能中断`, true);
    }
  } else {
    state.lowSpaceNotified = false;
  }
  if (state.route === 'detail') refreshDownloadBadges();
  else if (state.route === 'library' && state.libraryTab === 'downloads') renderLibrary();
};
let lastExportToast = '';
window.hgExportProgress = data => {
  if (!data) return;
  state.exports = data;
  const stateText = data.state || '';
  const terminal = stateText.startsWith('导出完成') || stateText.startsWith('导出失败')
    || stateText.indexOf('已存在') >= 0 || stateText.indexOf('没有可导出') >= 0;
  if (terminal && stateText !== lastExportToast) {
    lastExportToast = stateText;
    toast(stateText, stateText.startsWith('导出失败'));
  }
  if (state.route === 'library' && state.libraryTab === 'downloads') renderLibrary();
};

const scroll = document.getElementById('scroll');
const content = document.getElementById('content');
const compact = document.getElementById('compact-category');
const toastHost = document.getElementById('toast-host');
const updateOverlay = document.getElementById('update-overlay');
const updateDownloadButton = document.getElementById('update-download');
const updateLaterButton = document.getElementById('update-later');
const searchInput = document.getElementById('search-input');
const headerSettings = document.getElementById('header-settings');
const confirmOverlay = document.getElementById('confirm-overlay');
const categoryIds = { adult: ['ai-duanju', 'ai-manju'], ai: ['ai-huanlian', 'ai-mogai'] };
const popularTags = [
  ['dushi', '都市'], ['xiaoyuan', '校园'], ['gufeng', '古风'], ['haomen', '豪门'],
  ['chuanyue', '穿越'], ['chongsheng', '重生'], ['qihuan', '奇幻'], ['zhichang', '职场']
];
const tagGroups = [
  ['popular', '热门类型'], ['story', '故事题材'], ['setting', '场景与身份'],
  ['relationship', '人物与关系'], ['style', '外形风格'], ['plot', '情节元素'], ['other', '更多标签']
];
const state = {
  route: 'home', tab: 'home', sub: { adult: 0, ai: 0 }, home: null,
  category: null, categoryItems: [], detail: null, detailLoading: false, sourceItem: null,
  search: null, query: '', filter: 'all', banner: 0,
  listing: null, tags: null, tagsReturn: null, listingReturn: null, settingsReturn: null,
  libraryTab: 'history', libraryQuery: '',
  downloads: { items: [], used: 0, free: 0, warnBelow: 0 },
  downloadSelect: null,
  chigua: { items: [], channel: 'all', nextPage: null, loading: false },
  post: null, postReturn: null, postBookmarked: false, postBookmarks: { items: [] },
  topic: null, topicReturn: null,
  sourceGroup: '', sourceQueue: [], previous: null, compactHeld: false
};
let routeToken = 0;
let toastTimer;
let observer;
let listingObserver;
let categoryObserver;
const screenSnapshots = {};
let predictivePreview;
let predictiveTimer;
let predictiveSourceNode;
let predictiveFrame;
let pendingPredictiveProgress = 0;
let detailCard;
const coverRequests = new Map();
let bannerChanging = false;
let bannerTimer;
let lastDockTap = { tab: '', at: 0, navigated: false };
let updateChecking = false;
let updateDownloading = false;
let updateAvailable = null;
let appVersion = '';

const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const asArray = value => Array.isArray(value) ? value : [];
const icon = name => {
  const paths = {
    play: '<path d="m8 5 11 7-11 7z"/>',
    arrow: '<path d="m9 5 7 7-7 7"/>',
    back: '<path d="m15 5-7 7 7 7"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]}</svg>`;
};

function toast(message, info = false) {
  clearTimeout(toastTimer);
  toastHost.innerHTML = `<div class="toast ${info ? 'info' : ''}"><i></i><span>${esc(message)}</span></div>`;
  toastHost.classList.add('visible');
  toastTimer = setTimeout(() => toastHost.classList.remove('visible'), 3000);
}

let finishConfirmation;
function closeConfirmation(accepted) {
  if (confirmOverlay.hidden) return;
  confirmOverlay.hidden = true;
  finishConfirmation?.(accepted);
  finishConfirmation = null;
}
function askConfirmation(title, message, action = '清空') {
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-message').textContent = message;
  document.getElementById('confirm-accept').textContent = action;
  confirmOverlay.hidden = false;
  document.getElementById('confirm-cancel').focus();
  return new Promise(resolve => { finishConfirmation = resolve; });
}
document.getElementById('confirm-cancel').addEventListener('click', () => closeConfirmation(false));
document.getElementById('confirm-accept').addEventListener('click', () => closeConfirmation(true));
confirmOverlay.addEventListener('click', event => { if (event.target === confirmOverlay) closeConfirmation(false); });

window.hgWindowInsets = height => {
  document.getElementById('app').style.setProperty('--status-bar-height', `${Math.max(0, Number(height) || 0)}px`);
};
api('window-insets').then(window.hgWindowInsets).catch(() => {});
api('screen-corners').then(corners => {
  const app = document.getElementById('app');
  for (const name of ['topLeft', 'topRight', 'bottomRight', 'bottomLeft']) {
    const radius = Number(corners?.[name]);
    if (radius > 0) app.style.setProperty(`--screen-corner-${name}`, `${radius}px`);
  }
}).catch(() => {});

headerSettings.addEventListener('click', goSettings);

function setAvailableUpdate(result) {
  updateAvailable = result?.status === 'available' ? result : null;
  headerSettings.classList.toggle('has-update', Boolean(updateAvailable));
  const versionButton = content.querySelector('[data-open-update]');
  if (versionButton) {
    versionButton.classList.toggle('has-update', Boolean(updateAvailable));
    versionButton.setAttribute('aria-label', updateAvailable ? `当前版本 ${appVersion}，发现新版 ${updateAvailable.version}，查看更新` : `当前版本 ${appVersion}，检查更新`);
  }
}

function showUpdate(result) {
  document.getElementById('update-version').textContent = `当前 ${result.currentVersion} · 新版 ${result.version}`;
  const notes = document.getElementById('update-notes');
  notes.textContent = String(result.notes || '').trim().slice(0, 1200);
  notes.hidden = !notes.textContent;
  document.getElementById('update-progress').hidden = true;
  updateDownloadButton.textContent = '下载并安装';
  updateDownloadButton.disabled = false;
  updateOverlay.hidden = false;
}

async function checkUpdate(manual) {
  if (updateDownloading) { if (manual) toast('更新包正在下载', true); return; }
  if (updateChecking) { if (manual) toast('正在检查更新', true); return; }
  updateChecking = true;
  try {
    const result = await api('check-update', { manual });
    if (result.status === 'available') {
      setAvailableUpdate(result);
      if (manual) showUpdate(result);
    } else if (result.status === 'current' || result.status === 'unpublished' || result.status === 'none') {
      setAvailableUpdate(null);
      if (manual && result.status === 'current') toast(`已是最新版本 ${result.version}`);
      if (manual && result.status === 'unpublished') toast('暂未发布更新包', true);
    }
    else if (manual && result.status === 'throttled') toast('一小时内最多手动检查 5 次，请稍后再试', true);
  } catch (error) {
    if (manual) toast(error.message || '检查更新失败，请稍后重试', true);
  } finally { updateChecking = false; }
}

window.hgUpdateProgress = percent => {
  document.getElementById('update-progress').hidden = false;
  document.getElementById('update-percent').textContent = `${percent}%`;
  document.getElementById('update-fill').style.transform = `scaleX(${percent / 100})`;
};
window.hgUpdateInstallPermissionDenied = () => toast('请允许此应用安装更新包后重试', true);
window.hgUpdateInstallError = () => toast('无法打开系统安装程序，请重试', true);

updateDownloadButton.addEventListener('click', async () => {
  if (updateDownloading) return;
  updateDownloading = true;
  updateDownloadButton.disabled = true;
  updateLaterButton.disabled = true;
  updateDownloadButton.textContent = '正在下载…';
  window.hgUpdateProgress(0);
  try {
    await api('download-update');
    updateDownloadButton.textContent = '重新打开安装程序';
  } catch (error) {
    updateDownloadButton.textContent = '重试下载';
    toast(error.message || '下载失败，请重试', true);
  } finally {
    updateDownloading = false;
    updateDownloadButton.disabled = false;
    updateLaterButton.disabled = false;
  }
});
updateLaterButton.addEventListener('click', () => { if (!updateDownloading) updateOverlay.hidden = true; });

window.hgTheme = () => applyPalette(paletteId());
api('theme').then(window.hgTheme).catch(() => {});

const ACCENT_SWATCHES = ['#a855f7', '#4f7cff', '#06b6d4', '#27c08a', '#f59e0b', '#ef4444', '#ec4899'];
const PALETTES = [
  { id: 'violet', name: '紫色', dark: true, accent: '#a855f7' },
  { id: 'light', name: '浅色', dark: false, accent: '#7c3aed' },
  { id: 'dark', name: '深色', dark: true, accent: '#e8eaf0' },
  { id: 'custom', name: '自定义', dark: true, accent: '' }
];
function stored(key, fallback) {
  try { return localStorage.getItem(key) || fallback; } catch (error) { return fallback; }
}
function customAccent() {
  const value = stored('hg-accent', '#7c3aed');
  return /^#[0-9a-f]{6}$/i.test(value) ? value : '#7c3aed';
}
function customDark() { return stored('hg-custom-mode', 'dark') !== 'light'; }
function contrastOn(hex) {
  const value = parseInt(hex.slice(1), 16);
  const luminance = (0.299 * ((value >> 16) & 255) + 0.587 * ((value >> 8) & 255) + 0.114 * (value & 255)) / 255;
  return luminance > 0.62 ? '#12141a' : '#ffffff';
}
function paletteId() {
  const saved = stored('hg-palette', 'violet');
  return PALETTES.some(item => item.id === saved) ? saved : 'violet';
}
function applyPalette(id) {
  const palette = PALETTES.find(item => item.id === id) || PALETTES[0];
  const dark = palette.id === 'custom' ? customDark() : palette.dark;
  const accent = palette.id === 'custom' ? customAccent() : palette.accent;
  document.documentElement.dataset.palette = palette.id;
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.documentElement.style.setProperty('--accent', accent);
  document.documentElement.style.setProperty('--on-accent', contrastOn(accent));
  api('chrome', { dark }).catch(() => {});
  return palette;
}
applyPalette(paletteId());

function itemCard(item) {
  const id = esc(item.id);
  const title = esc(item.title || '影片');
  const info = esc(item.episodeLabel || asArray(item.tags).slice(0, 2).join(' · ') || '打开详情');
  return `<button class="film-card" type="button" data-open-id="${id}" aria-label="查看${title}">
    <span class="poster loading"><span class="poster-letter">${title.slice(0, 1)}</span><img data-cover="${esc(item.cover || '')}" alt=""><span class="poster-score" ${item.score ? '' : 'hidden'}>${esc(item.score || '')}</span></span>
    <span class="film-title">${title}</span><span class="film-info">${info}</span></button>`;
}

function section(title, items, kind = '') {
  if (!items.length) return '';
  return `<section class="film-section"><div class="section-heading"><h2>${esc(title)}</h2>${kind ? `<button class="more" data-more="${kind}" type="button">更多 ${icon('arrow')}</button>` : ''}</div><div class="film-row">${items.map(itemCard).join('')}</div></section>`;
}
function homeTagBar() {
  return `<nav class="home-tags" aria-label="按类型浏览"><button type="button" class="all-tags-link" data-all-tags="1">全部类型 ${icon('arrow')}</button>
    <div class="home-tag-scroll">${popularTags.map(([slug, name]) => `<button type="button" class="home-tag" data-tag-slug="${slug}" data-tag-name="${name}">${name}</button>`).join('')}</div></nav>`;
}

function homeSignature(data) {
  return JSON.stringify([asArray(data.featured), asArray(data.homepageRecommend), asArray(data.homepageNewest), asArray(data.homepageCategory), asArray(data.recommend?.items), asArray(data.newest?.items)]
    .map(list => list.map(item => [item.id, item.title, item.episodeLabel, item.score])));
}
function listSignature(data) {
  return JSON.stringify(asArray(data.items).map(item => [item.id, item.title, item.episodeLabel, item.score]));
}

function paletteFromImage(image) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 48;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  context.drawImage(image, 0, 0, 48, 48);
  const pixels = context.getImageData(0, 0, 48, 48).data;
  let red = 0, green = 0, blue = 0, weightSum = 0;
  for (let index = 0; index < pixels.length; index += 16) {
    const r = pixels[index], g = pixels[index + 1], b = pixels[index + 2];
    const brightness = (r + g + b) / 3;
    if (brightness < 28 || brightness > 225) continue;
    const weight = 0.6 + (Math.max(r, g, b) - Math.min(r, g, b)) / 255;
    red += r * weight; green += g * weight; blue += b * weight; weightSum += weight;
  }
  if (!weightSum) throw new Error('未找到可用颜色');
  const r = red / weightSum / 255, g = green / weightSum / 255, b = blue / weightSum / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), difference = max - min;
  let hue = 28;
  if (difference) {
    hue = max === r ? ((g - b) / difference) % 6 : max === g ? (b - r) / difference + 2 : (r - g) / difference + 4;
    hue = (hue * 60 + 360) % 360;
  }
  const saturation = Math.round(Math.max(17, Math.min(32, difference / Math.max(max, .01) * 75)));
  return { light: `hsl(${Math.round(hue)} ${saturation}% 62%)`, dark: `hsl(${Math.round(hue)} ${Math.min(34, saturation + 2)}% 25%)` };
}
function applyBannerPalette(image) {
  const slide = image.closest('.hero-slide') || image.closest('.hero');
  if (!slide) return;
  const key = (image.dataset.cover || '').split('?')[0];
  let cache = {};
  try { cache = JSON.parse(localStorage.getItem('banner-palettes') || '{}'); } catch { }
  let colors = cache[key];
  if (!colors) {
    try { colors = paletteFromImage(image); cache[key] = colors; localStorage.setItem('banner-palettes', JSON.stringify(cache)); }
    catch { colors = { light: '#B5A08B', dark: '#49332F' }; }
  }
  slide.style.setProperty('--hero-tint-light', colors.light);
  slide.style.setProperty('--hero-tint-dark', colors.dark);
}

function coverKey(url) {
  try { return new URL(url).pathname; } catch { return String(url).split('?')[0]; }
}
function getCover(url) {
  const key = coverKey(url);
  if (coverRequests.has(key)) return coverRequests.get(key);
  const request = api('cover', { url }).catch(error => { coverRequests.delete(key); throw error; });
  coverRequests.set(key, request);
  if (coverRequests.size > 80) coverRequests.delete(coverRequests.keys().next().value);
  return request;
}
async function loadCoverInto(image) {
  const url = image.dataset.cover;
  if (image.dataset.loading === '1') return;
  if (!url) {
    image.closest('.poster')?.classList.remove('loading');
    image.closest('.poster')?.classList.add('fallback');
    return;
  }
  image.dataset.loading = '1';
  const poster = image.closest('.poster');
  try {
    let data;
    try { data = await getCover(url); }
    catch { await new Promise(resolve => setTimeout(resolve, 450)); data = await getCover(url); }
    if (!image.isConnected || image.dataset.cover !== url) return;
    await new Promise((resolve, reject) => {
      image.onload = () => { image.onload = image.onerror = null; resolve(); };
      image.onerror = () => { image.onload = image.onerror = null; reject(new Error('图片无法解码')); };
      image.src = data;
      if (image.complete && image.naturalWidth > 0) { image.onload = image.onerror = null; resolve(); }
    });
    if (!image.isConnected || image.dataset.cover !== url) return;
    poster?.classList.remove('loading', 'fallback');
    poster?.classList.add('has-image');
    delete image.dataset.retryAfter;
    if (image.classList.contains('hero-image')) applyBannerPalette(image);
  } catch (error) {
    coverRequests.delete(coverKey(url));
    if (image.isConnected) {
      image.removeAttribute('src');
      poster?.classList.remove('loading');
      poster?.classList.add('fallback');
      image.dataset.retryAfter = String(Date.now() + (error.message === '图片无法解码' ? 300000 : 30000));
    }
    const id = image.closest('[data-open-id]')?.dataset.openId || image.closest('.hero-slide,.category-spotlight')?.querySelector('[data-open-id]')?.dataset.openId || 'unknown';
    console.warn('封面加载失败', id, (() => { try { return new URL(url).host; } catch { return 'invalid'; } })(), error.message);
  } finally { delete image.dataset.loading; }
}

function retryFailedImages(force = false) {
  const viewport = scroll.getBoundingClientRect();
  content.querySelectorAll('img[data-cover]').forEach(image => {
    if (image.naturalWidth > 0 || image.dataset.loading === '1') return;
    if (!force && Date.now() < Number(image.dataset.retryAfter || 0)) return;
    const card = image.closest('.poster');
    if (card && !card.classList.contains('fallback')) return;
    const box = image.getBoundingClientRect();
    if (box.bottom < viewport.top - 320 || box.top > viewport.bottom + 320) return;
    const row = image.closest('.film-row');
    if (row) {
      const visible = row.getBoundingClientRect();
      if (box.right < visible.left - 250 || box.left > visible.right + 250) return;
    }
    card?.classList.remove('fallback');
    card?.classList.add('loading');
    loadCoverInto(image);
  });
}
let coverScrollTimer;
scroll.addEventListener('scroll', () => {
  clearTimeout(coverScrollTimer);
  coverScrollTimer = setTimeout(() => retryFailedImages(), 160);
}, { passive: true });
window.addEventListener('online', () => retryFailedImages(true));
function hydrateImages(root = content) {
  if (observer) observer.disconnect();
  observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const image = entry.target;
      observer.unobserve(image);
      loadCoverInto(image);
    });
  }, { root: scroll, rootMargin: '320px' });
  root.querySelectorAll('img[data-cover]').forEach((image, index) => {
    if (image.naturalWidth > 0) return;
    if (index < 14 || image.classList.contains('hero-image')) loadCoverInto(image);
    else observer.observe(image);
  });
}

function activeCampaigns() {
  const now = Date.now();
  return asArray(window.HotRuntime?.theme?.campaigns).filter(item => item?.id
    && (!item.startsAt || now >= Date.parse(item.startsAt))
    && (!item.endsAt || now < Date.parse(item.endsAt))
    && /^theme\/[a-zA-Z0-9_./-]+$/.test(item.artwork || '') && !item.artwork.split('/').includes('..'));
}
function campaignArtwork(item) {
  return new URL(item.artwork, 'https://appassets.androidplatform.net/assets/').href;
}
function homeSlides() {
  const featured = asArray(state.home?.featured);
  const videos = featured.length ? featured : asArray(state.home?.recommend?.items).slice(0, 5);
  return [...activeCampaigns().map(item => ({ ...item, kind: 'campaign', cover: '' })), ...videos];
}
function campaignSlide(item, index, count) {
  return '<div class="hero-slide hero-campaign" data-index="' + index + '">'
    + '<img class="hero-image campaign-image" src="' + esc(campaignArtwork(item)) + '" alt="">'
    + '<button class="hero-cover-button" type="button" data-open-campaign="' + esc(item.id) + '" aria-label="查看国庆庆祝页"></button>'
    + '<div class="hero-copy"><h2>' + esc(item.title) + '</h2><p>' + esc(item.description || '').replaceAll('\n', '<br>') + '</p>'
    + '<button class="hero-action" type="button" data-open-campaign="' + esc(item.id) + '">' + esc(item.button || '查看庆祝页') + '</button></div>'
    + '<span class="campaign-date">' + esc(item.dateLabel || '') + '</span>'
    + '<div class="hero-index"><b>' + String(index + 1).padStart(2, '0') + '</b> / ' + String(count).padStart(2, '0') + '</div></div>';
}
function goCampaign(item) {
  state.campaignReturn = captureScreen();
  ++routeToken;
  setRoute('campaign');
  state.campaign = item;
  content.innerHTML = '<article class="campaign-page"><button class="campaign-back" type="button" data-back>' + icon('back') + ' 返回首页</button>'
    + '<section class="campaign-poster"><img src="' + esc(campaignArtwork(item)) + '" alt="">'
    + '<div><h1>' + esc(item.title) + '</h1><p>' + esc(item.description || '').replaceAll('\n', '<br>') + '</p><span>' + esc(item.dateLabel || '') + '</span></div></section>'
    + '<section class="campaign-message"><h2>共庆好时光</h2><p>' + esc(item.message || '') + '</p><button type="button" data-back>返回首页</button></section></article>';
  scroll.scrollTop = 0;
}
function stopBannerAuto() {
  clearTimeout(bannerTimer);
  bannerTimer = null;
}
function scheduleBannerAuto() {
  stopBannerAuto();
  if (state.route !== 'home' || document.hidden || homeSlides().length < 2 || !content.querySelector('.hero')) return;
  bannerTimer = setTimeout(() => {
    bannerTimer = null;
    if (state.route !== 'home' || document.hidden) return;
    const count = homeSlides().length;
    if (count > 1) changeBanner((state.banner + 1) % count, 1, true);
  }, 3000);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) stopBannerAuto();
  else scheduleBannerAuto();
});
function heroSlide(item, index, count) {
  if (item.kind === 'campaign') return campaignSlide(item, index, count);
  return `<div class="hero-slide" data-index="${index}"><img class="hero-image" data-cover="${esc(item.cover || '')}" alt=""><button class="hero-cover-button" type="button" data-open-id="${esc(item.id || '')}" aria-label="查看${esc(item.title || '作品')}详情"></button><div class="hero-shade"></div>
    <div class="hero-copy"><span class="hero-label">本周焦点 <i></i> 独家精选</span><h2>${esc(item.title || '为你推荐')}</h2><p>${esc(item.description || item.episodeLabel || '')}</p><button class="hero-action" data-open-id="${esc(item.id || '')}" type="button">${icon('play')} 立即观看</button></div>
    <div class="hero-index"><b>${String(index + 1).padStart(2, '0')}</b> / ${String(count).padStart(2, '0')}</div></div>`;
}
async function changeBanner(targetIndex, direction, automatic = false) {
  const slides = homeSlides();
  const hero = content.querySelector('.hero');
  if (!hero || !slides.length || bannerChanging || targetIndex === state.banner) return;
  stopBannerAuto();
  bannerChanging = true;
  let incoming = null;
  try {
    const item = slides[targetIndex];
    const data = item.kind === 'campaign' ? campaignArtwork(item) : await getCover(item.cover);
    const template = document.createElement('template');
    template.innerHTML = heroSlide(item, targetIndex, slides.length);
    incoming = template.content.firstElementChild;
    const image = incoming.querySelector('img');
    image.src = data;
    if (!hero.isConnected || state.route !== 'home' || document.hidden) return;
    incoming.style.transform = `translateX(${direction > 0 ? 100 : -100}%)`;
    hero.appendChild(incoming);
    await image.decode();
    if (!hero.isConnected || state.route !== 'home' || document.hidden) { incoming.remove(); return; }
    if (item.kind !== 'campaign') applyBannerPalette(image);
    const current = hero.querySelector('.hero-slide:not(:last-child)');
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    incoming.classList.add('animating');
    current.classList.add('animating');
    incoming.style.transform = 'translateX(0)';
    current.style.transform = `translateX(${direction > 0 ? -100 : 100}%)`;
    await new Promise(resolve => setTimeout(resolve, 330));
    current.remove();
    incoming.classList.remove('animating');
    incoming.style.transform = '';
    state.banner = targetIndex;
    content.querySelectorAll('.hero-dots [data-slide]').forEach(dot => dot.classList.toggle('active', Number(dot.dataset.slide) === targetIndex));
  } catch (error) {
    incoming?.remove();
    hero.querySelectorAll('.hero-slide').forEach(slide => { slide.classList.remove('animating'); slide.style.transform = ''; });
    if (!automatic) toast('封面加载失败，请重试', true);
  }
  finally { bannerChanging = false; scheduleBannerAuto(); }
}
function renderHome() {
  const data = state.home;
  if (!data) { renderSkeleton(); return; }
  const slides = homeSlides();
  const index = Math.min(state.banner, Math.max(0, slides.length - 1));
  const selected = slides[index] || {};
  content.innerHTML = `<div class="home-page"><div class="hero" data-hero="1">${heroSlide(selected, index, slides.length)}</div>
      <div class="hero-dots">${slides.map((_, i) => `<i class="${i === index ? 'active' : ''}" data-slide="${i}"></i>`).join('')}</div>
      ${homeTagBar()}
      ${section('精选推荐', asArray(data.homepageRecommend).length ? asArray(data.homepageRecommend) : asArray(data.recommend?.items).slice(0, 12), 'recommend')}
      ${section('最近上新', asArray(data.homepageNewest).length ? asArray(data.homepageNewest) : asArray(data.newest?.items).slice(0, 12), 'newest')}
      ${categorySection(asArray(data.homepageCategory))}
      ${rankSection()}
      ${topicsSection(asArray(data.topics))}</div>`;
  hydrateImages();
  loadRank();
  slides.forEach(item => { if (item.cover) getCover(item.cover).catch(() => {}); });
  scheduleBannerAuto();
}

function categorySection(items) {
  if (!items.length) return '';
  return `<section class="film-section cat-section"><div class="section-heading"><h2>分类推荐</h2></div>
    <div class="cat-row">${items.slice(0, 10).map(item => `<button type="button" class="cat-card" data-open-id="${esc(item.id)}">
      <span class="cat-cover"><img data-cover="${esc(item.cover || '')}" alt=""></span>
      <span class="cat-copy"><span class="cat-kicker">${esc(item.category || '推荐')}</span>
      <span class="cat-title">${esc(item.title)}</span><span class="cat-desc">${esc(item.description || '')}</span></span>
    </button>`).join('')}</div></section>`;
}

function rankSection() {
  return `<section class="film-section rank-section"><div class="section-heading"><h2>热播榜</h2><span class="section-note">实时热力</span></div>
    <div class="rank-list" data-rank-host>${state.rank ? rankRows(state.rank) : '<div class="rank-loading">正在加载…</div>'}</div></section>`;
}

function rankRows(items) {
  if (!items.length) return '<div class="rank-loading">榜单暂时不可用</div>';
  return items.map(item => `<button type="button" class="rank-row" data-open-id="${esc(item.id)}">
    <span class="rank-no">${String(item.rank).padStart(2, '0')}</span>
    <span class="rank-cover"><img data-cover="${esc(item.cover || '')}" alt=""></span>
    <span class="rank-copy"><span class="rank-title">${esc(item.title)}</span>
    <span class="rank-meta">${item.score ? esc(item.score) + '分 · ' : ''}${esc(item.heat || '')}${item.heat ? ' 热力' : ''}</span></span>
  </button>`).join('');
}

async function loadRank() {
  if (state.rank || state.rankLoading) return;
  state.rankLoading = true;
  try { state.rank = asArray((await api('rank')).items); }
  catch (error) { state.rank = []; }
  state.rankLoading = false;
  const host = document.querySelector('[data-rank-host]');
  if (host) { host.innerHTML = rankRows(state.rank); hydrateImages(); }
}

function topicsSection(topics) {
  if (!topics.length) return '';
  return `<section class="film-section topic-section"><div class="section-heading"><h2>专题推荐</h2></div>
    <div class="topic-row">${topics.map(item => `<button type="button" class="topic-card" data-topic-slug="${esc(item.slug)}" data-topic-title="${esc(item.title)}">
      <span class="topic-cover"><img data-cover="${esc(item.cover)}" alt=""></span>
      <strong>${esc(item.title)}</strong><small>${esc(item.meta || '')}</small></button>`).join('')}</div></section>`;
}

function chiguaCard(item) {
  const meta = [item.author, item.date].filter(Boolean).join(' · ');
  return `<button type="button" class="chigua-card" data-post-id="${esc(item.id)}">
    <span class="chigua-cover"><img data-cover="${esc(item.cover)}" alt=""></span>
    <strong>${esc(item.title)}</strong><small>${esc(meta)}</small></button>`;
}

function renderChigua() {
  const view = state.chigua || { items: [], channel: 'all', nextPage: null, loading: false };
  const channels = [['all', '全部'], ['hot', '热门吃瓜'], ['original', 'AI原创']];
  content.innerHTML = `<div class="chigua-page"><h1>吃瓜</h1>
    <div class="chigua-channels">${channels.map(([id, name]) =>
      `<button type="button" class="chigua-channel ${view.channel === id ? 'selected' : ''}" data-chigua-channel="${id}">${name}</button>`).join('')}</div>
    ${view.items.length ? `<div class="chigua-grid">${view.items.map(chiguaCard).join('')}</div>` : '<p class="empty-state">暂时没有内容，稍后再来看看</p>'}
    <div class="chigua-footer">${view.nextPage ? `<button type="button" class="chigua-more" data-chigua-more="1" ${view.loading ? 'disabled' : ''}>${view.loading ? '加载中…' : '加载更多'}</button>` : (view.items.length ? '<span>没有更多了</span>' : '')}</div></div>`;
  hydrateImages();
}

async function goChigua(channel = 'all', page = 1) {
  const token = ++routeToken;
  if (page === 1) {
    if (state.route === 'home') rememberScreen();
    state.chigua = { items: [], channel, nextPage: null, loading: true };
    setRoute('chigua'); state.tab = 'chigua'; setNav('chigua');
    renderSkeleton();
  } else {
    state.chigua.loading = true;
    renderChigua();
  }
  try {
    const data = await api('chigua', { page, channel });
    if (token !== routeToken) return;
    const items = page === 1 ? asArray(data.items) : [...state.chigua.items, ...asArray(data.items)];
    state.chigua = { items, channel, nextPage: data.nextPage || null, loading: false };
    renderChigua();
  } catch (error) {
    if (token !== routeToken) return;
    state.chigua.loading = false;
    if (page === 1) renderError(error, 'chigua');
    else { renderChigua(); toast('加载失败，请稍后重试', true); }
  }
}

function renderPost() {
  const post = state.post;
  if (!post) { renderSkeleton(); return; }
  const meta = [post.author, post.date, post.views ? `${post.views} 阅读` : ''].filter(Boolean).join(' · ');
  const videos = asArray(post.videos).map(video => `<button type="button" class="post-video" data-play-post="1"
      data-url="${esc(video.src)}" data-poster="${esc(video.poster || '')}">
      ${video.poster ? `<img data-cover="${esc(video.poster)}" alt="">` : ''}
      <span class="post-play">${icon('play')}</span></button>`).join('');
  const blocks = asArray(post.blocks).map(block => {
    if (block.type === 'img') return `<img class="post-image" data-cover="${esc(block.src)}" data-view="1" alt="">`;
    if (block.type === 'h2') return `<h2>${esc(block.text)}</h2>`;
    return `<p>${esc(block.text)}</p>`;
  }).join('');
  content.innerHTML = `<div class="post-page"><button class="listing-back" type="button" data-back="1">${icon('back')} 返回吃瓜</button>
    <h1 class="post-title">${esc(post.title)}</h1>
    <div class="post-meta-row"><p class="post-meta">${esc(meta)}</p>
      <button type="button" class="post-bookmark ${state.postBookmarked ? 'active' : ''}" data-post-bookmark="1">${state.postBookmarked ? '★ 已收藏' : '☆ 收藏'}</button></div>
    ${videos}${blocks}</div>`;
  hydrateImages();
  scroll.scrollTop = 0;
}

async function goPost(id) {
  const token = ++routeToken;
  state.postId = id;
  state.postReturn = captureScreen();
  setRoute('post'); state.tab = 'chigua'; state.post = null; renderSkeleton();
  try {
    const post = await api('post', { id });
    if (token !== routeToken) return;
    state.post = post;
    renderPost();
    api('post-bookmark-state', { id }).then(saved => {
      if (token === routeToken && state.route === 'post') { state.postBookmarked = Boolean(saved); renderPost(); }
    }).catch(() => {});
  } catch (error) { if (token === routeToken) renderError(error, 'post'); }
}

function openImageViewer(source) {
  if (!source) return;
  const overlay = document.createElement('div');
  overlay.className = 'image-viewer';
  overlay.innerHTML = `<img src="${esc(source)}" alt=""><button type="button" class="image-viewer-close" aria-label="关闭">×</button>`;
  overlay.addEventListener('click', () => overlay.remove());
  document.getElementById('app').appendChild(overlay);
}

function renderTopic() {
  const topic = state.topic;
  if (!topic) { renderSkeleton(); return; }
  content.innerHTML = `<div class="listing-page"><button class="listing-back" type="button" data-back="1">${icon('back')} 返回首页</button>
    <h1>${esc(topic.title)}</h1>
    ${topic.description ? `<p class="topic-desc">${esc(topic.description)}</p>` : ''}
    <p>共 ${asArray(topic.items).length} 部作品</p>
    <div class="search-grid">${asArray(topic.items).map(itemCard).join('')}</div></div>`;
  hydrateImages();
}

async function goTopic(slug, title) {
  const token = ++routeToken;
  state.topicSlug = slug;
  state.topicReturn = captureScreen();
  setRoute('topic'); state.tab = 'home'; state.topic = { title: title || '专题', items: [] }; renderSkeleton();
  try {
    const topic = await api('topic', { slug });
    if (token !== routeToken) return;
    state.topic = topic;
    renderTopic();
    scroll.scrollTop = 0;
  } catch (error) { if (token === routeToken) renderError(error, 'topic'); }
}

function renderTags() {
  const tags = asArray(state.tags?.items);
  const groups = tagGroups.map(([id, title]) => {
    const members = tags.filter(tag => tag.group === id);
    if (!members.length) return '';
    return `<section class="tags-group"><h2>${title}</h2><div class="tags-grid">${members.map(tag => {
      const name = String(tag.name || tag.slug);
      const size = name.length > 8 ? 'wide' : name.length > 4 ? 'medium' : '';
      return `<button type="button" class="tag-choice ${size}" data-tag-slug="${esc(tag.slug)}" data-tag-name="${esc(name)}">${esc(name)}</button>`;
    }).join('')}</div></section>`;
  }).join('');
  content.innerHTML = `<div class="tags-page"><div class="tags-heading"><button type="button" data-back="1" aria-label="返回首页">${icon('back')}</button><h1>全部类型</h1><span>${tags.length} 个标签</span></div>
    <p class="tags-intro">点选标签，发现相关作品</p>${groups}</div>`;
}

function refreshMissingImages(items) {
  const byId = new Map(items.filter(item => item?.id && item?.cover).map(item => [String(item.id), item.cover]));
  content.querySelectorAll('[data-open-id]').forEach(button => {
    const image = button.querySelector('img[data-cover]') || button.closest('.hero-slide,.category-spotlight')?.querySelector('img[data-cover]');
    const cover = byId.get(button.dataset.openId);
    if (!image || !cover || image.naturalWidth > 0) return;
    image.dataset.cover = cover;
    delete image.dataset.loading;
    loadCoverInto(image);
  });
}

function categoryId() { return categoryIds[state.tab][state.sub[state.tab]]; }
function compactMarkup() {
  const adult = state.tab === 'adult';
  const tabs = adult ? ['成人短剧', '成人漫剧'] : ['AI换脸', 'AI魔改'];
  return `<strong>${adult ? '成人剧场' : 'AI专区'}</strong><div class="compact-tabs" role="tablist">${tabs.map((name, index) => `<button type="button" role="tab" aria-selected="${index === state.sub[state.tab]}" data-sub="${index}" class="${index === state.sub[state.tab] ? 'selected' : ''}">${name}</button>`).join('')}</div>`;
}
function updateCompact() {
  const eligible = state.route === 'category';
  if (!eligible || scroll.scrollTop <= 0) state.compactHeld = false;
  else if (scroll.scrollTop > 92) state.compactHeld = true;
  const visible = eligible && state.compactHeld;
  compact.classList.toggle('visible', visible);
  compact.setAttribute('aria-hidden', String(!visible));
  compact.inert = !visible;
  content.querySelector('.category-page')?.classList.toggle('is-collapsed', visible);
}
scroll.addEventListener('scroll', updateCompact, { passive: true });

function renderCategory(keepCompact = false) {
  categoryObserver?.disconnect();
  const adult = state.tab === 'adult';
  const tabs = adult ? ['成人短剧', '成人漫剧'] : ['AI换脸', 'AI魔改'];
  const items = asArray(state.category?.items);
  const lead = items[0] || null;
  content.innerHTML = `<div class="category-page"><div class="category-head"><h1>${adult ? '成人剧场' : 'AI专区'}</h1><p>${adult ? '短剧与漫剧，走进不同的人生。' : '换脸与魔改，探索影像新可能。'}</p></div>
    <div class="segmented" role="tablist">${tabs.map((name, index) => `<button type="button" role="tab" data-sub="${index}" aria-selected="${index === state.sub[state.tab]}" class="${index === state.sub[state.tab] ? 'selected' : ''}">${name}</button>`).join('')}</div>
    ${lead ? `<div class="category-spotlight"><img data-cover="${esc(lead.cover)}" alt=""><div class="category-spotlight-copy"><h2>${esc(lead.title)}</h2><button type="button" data-open-id="${esc(lead.id)}">查看作品 ${icon('arrow')}</button></div></div>` : ''}
    <section class="category-section"><div class="section-heading"><h2>${tabs[state.sub[state.tab]]}作品</h2><span class="category-count">已显示 ${items.length} 部</span></div>
    <div class="search-grid category-grid">${items.map(itemCard).join('')}</div><div class="category-footer">${categoryFooter()}</div></section></div>`;
  compact.innerHTML = compactMarkup();
  scroll.scrollTop = keepCompact ? 150 : 0;
  state.compactHeld = keepCompact;
  updateCompact();
  hydrateImages();
  observeCategoryEnd();
}

function categoryFooter() {
  const category = state.category;
  if (category?.error) return '<button type="button" data-retry-category="1">加载失败，点击重试</button>';
  if (category?.loading) return '<span role="status">正在加载更多…</span>';
  if (category?.refreshing) return '<span role="status">正在更新列表…</span>';
  if (category?.nextPage) return '<span class="category-sentinel" aria-hidden="true"></span>';
  return '<span>已经到底了</span>';
}

function observeCategoryEnd() {
  categoryObserver?.disconnect();
  const category = state.category;
  if (state.route !== 'category' || !category?.nextPage || category.loading || category.refreshing || category.error) return;
  const sentinel = content.querySelector('.category-sentinel');
  if (!sentinel) return;
  if (!categoryObserver) {
    categoryObserver = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) loadMoreCategory();
    }, { root: scroll, rootMargin: '0px 0px 320px 0px' });
  }
  categoryObserver.observe(sentinel);
}

function updateCategoryFooter() {
  const footer = content.querySelector('.category-footer');
  if (!footer) return;
  footer.innerHTML = categoryFooter();
  observeCategoryEnd();
}

function renderLibrary() {
  const data = state.library || { progress: [], bookmarks: [] };
  const query = state.libraryQuery.trim().toLocaleLowerCase();
  const matches = item => String(item.title || '').toLocaleLowerCase().includes(query);
  const progress = asArray(data.progress).filter(matches);
  const bookmarks = asArray(data.bookmarks).filter(matches);
  const historyActive = state.libraryTab === 'history';
  const downloadsActive = state.libraryTab === 'downloads';
  const postsActive = state.libraryTab === 'posts';
  const missAvActive = state.libraryTab === 'missav';
  const posts = asArray(state.postBookmarks?.items).filter(matches);
  const historyCards = progress.map(item => {
    const completed = Boolean(item.completed);
    const episode = Number(item.episode) || 1;
    const percentage = completed ? 100 : Math.max(0, Math.min(100, item.duration ? item.position / item.duration * 100 : 0));
    return `<button type="button" class="history-card" data-history-id="${esc(item.id)}" data-history-episode="${episode}" data-history-completed="${completed}" aria-label="${esc(item.title)}，第 ${episode} 集，${completed ? '已看完，打开详情' : '继续观看'}">
      <span class="history-poster poster loading"><span class="poster-letter">${esc(String(item.title || '影片').slice(0, 1))}</span><img data-cover="${esc(item.cover || '')}" alt=""></span><span class="history-copy"><span class="history-status">${completed ? '已看完' : '继续观看'} · 第 ${episode} 集</span>
      <strong>${esc(item.title || '影片')}</strong><span class="progress"><i style="width:${percentage}%"></i></span><span class="history-hint">${completed ? '打开详情选择剧集' : `已看 ${Math.floor(item.position / 60000)} 分钟`}</span></span></button>`;
  }).join('');
  content.innerHTML = `<div class="library-page"><div class="my-heading"><h1>我的</h1></div>
    ${query ? `<div class="library-results"><p class="library-count">在观看历史中找到 ${progress.length} 部，在我的收藏中找到 ${bookmarks.length} 部</p>
      <h2>观看历史</h2>${progress.length ? `<div class="history-list">${historyCards}</div>` : '<p class="library-no-match">没有匹配的观看记录</p>'}
      <h2>我的收藏</h2>${bookmarks.length ? `<div class="search-grid library-bookmark-grid">${bookmarks.map(itemCard).join('')}</div>` : '<p class="library-no-match">没有匹配的收藏</p>'}</div>` : `
    <div class="segmented library-tabs" role="tablist" aria-label="我的片单分类"><button type="button" role="tab" data-library-tab="history" aria-selected="${historyActive}" class="${historyActive ? 'selected' : ''}">观看历史</button>
    <button type="button" role="tab" data-library-tab="bookmarks" aria-selected="${!historyActive && !downloadsActive && !postsActive && !missAvActive}" class="${!historyActive && !downloadsActive && !postsActive && !missAvActive ? 'selected' : ''}">我的收藏</button>
    <button type="button" role="tab" data-library-tab="downloads" aria-selected="${downloadsActive}" class="${downloadsActive ? 'selected' : ''}">我的下载</button>
    <button type="button" role="tab" data-library-tab="posts" aria-selected="${postsActive}" class="${postsActive ? 'selected' : ''}">吃瓜收藏</button>
    <button type="button" role="tab" data-library-tab="missav" aria-selected="${missAvActive}" class="${missAvActive ? 'selected' : ''}">仓库</button></div>
    <p class="library-count">${downloadsActive ? `已用 ${formatBytes(state.downloads.used)} · 手机剩余 ${formatBytes(state.downloads.free)}` : postsActive ? `已收藏 ${posts.length} 篇吃瓜` : missAvActive ? `仓库观看记录 ${missAvHistory().length} 条` : historyActive ? `最近观看的 ${progress.length} 部作品` : `已收藏 ${bookmarks.length} 部作品`}</p>
    ${downloadsActive ? renderDownloads() : postsActive ? (posts.length ? `<div class="chigua-grid library-post-grid">${posts.map(chiguaCard).join('')}</div>` : '<div class="empty-state">还没有收藏吃瓜内容，进入吃瓜详情点"☆ 收藏"</div>') : missAvActive ? renderMissAvHistory() : historyActive ? (progress.length ? `<div class="history-list">${historyCards}</div>` : '<div class="empty-state">还没有观看记录，播放作品后会出现在这里</div>') :
      (bookmarks.length ? `<div class="search-grid library-bookmark-grid">${bookmarks.map(itemCard).join('')}</div>` : '<div class="empty-state">还没有收藏作品</div>')}`}</div>`;
  hydrateImages();
}

function renderMissAvHistory() {
  const list = missAvHistory();
  if (!list.length) return '<div class="empty-state">还没有仓库观看记录</div>';
  return `<div class="mv-history-manage"><div class="mv-history-head"><span>共 ${list.length} 条</span><button type="button" data-mv-history-clear="1">清空记录</button></div>
    ${list.map(item => `<div class="mv-history-item">
      <button type="button" class="mv-history-open" data-mv-open="${esc(item.id)}" data-mv-cover="${esc(item.cover || '')}"><img src="${esc(item.cover || '')}" alt="" referrerpolicy="no-referrer"><span><strong>${esc(item.title)}</strong><small>${esc(new Date(item.at || Date.now()).toLocaleDateString())}</small></span></button>
      <button type="button" class="mv-history-del" data-mv-history-delete="${esc(item.id)}" aria-label="删除记录">×</button></div>`).join('')}</div>`;
}

function renderDownloads() {
  const items = asArray(state.downloads?.items);
  if (!items.length) return '<div class="empty-state">还没有下载。打开剧集详情页，点选集右上角的 ⬇ 或"下载整部"</div>';
  const groups = new Map();
  for (const item of items) {
    const group = groups.get(item.id) || { id: item.id, title: item.title || '影片', cover: item.cover || '', episodes: [], bytes: 0, done: 0 };
    group.episodes.push(item);
    group.bytes += Number(item.bytes) || 0;
    if (item.status === 'done') group.done += 1;
    groups.set(item.id, group);
  }
  const free = Number(state.downloads?.free) || 0;
  const warnBelow = Number(state.downloads?.warnBelow) || 1024 * 1024 * 1024;
  const lowSpace = free > 0 && free < warnBelow;
  const ex = state.exports || {};
  const exporting = !!ex.title && (ex.state === '导出中' || ex.state === '已导出' || ex.state === '合并中');
  const exportFailed = !!ex.title && typeof ex.state === 'string' && ex.state.indexOf('导出失败') === 0;
  let exportPanel = '';
  if (exporting && Number(ex.total) > 0) {
    const overall = Math.min(100, Math.round(((Number(ex.done) || 0) + (ex.state === '导出中' ? (Number(ex.percent) || 0) / 100 : 0)) / Number(ex.total) * 100));
    exportPanel = `<div class="export-panel"><div class="export-panel-head"><strong>正在导出「${esc(ex.title)}」</strong><small>${ex.state === '导出中' && ex.episode ? `第 ${ex.episode} 集 ${ex.percent || 0}%` : '正在保存'} · 已完成 ${Number(ex.done) || 0}/${Number(ex.total)} 集</small></div><div class="export-bar"><i style="width:${overall}%"></i></div></div>`;
  } else if (exportFailed) {
    exportPanel = `<p class="download-warning">${esc(ex.state)}</p>`;
  }
  return `<div class="download-list">${exportPanel}${lowSpace ? `<p class="download-warning">手机剩余存储不足（${formatBytes(free)}），继续下载可能中断；清理空间后会自动恢复</p>` : ''}${[...groups.values()].map(group => {
    group.episodes.sort((a, b) => Number(a.episode) - Number(b.episode));
    const expanded = !!(state.downloadExpanded && state.downloadExpanded[group.id]);
    const visible = expanded ? group.episodes : group.episodes.slice(0, 12);
    const selecting = state.downloadSelect && state.downloadSelect.id === group.id;
    const selectedKeys = new Set(selecting ? state.downloadSelect.keys : []);
    const chips = visible.map(item => {
      if (selecting) {
        const selected = selectedKeys.has(item.key);
        const cls = item.status === 'done' ? 'done' : item.status === 'downloading' || item.status === 'queued' ? 'busy' : '';
        return `<button type="button" class="download-chip ${cls} ${selected ? 'selected' : ''}" data-select-key="${esc(item.key)}" aria-pressed="${selected}">${item.episode}</button>`;
      }
      if (item.status === 'done')
        return `<button type="button" class="download-chip done" data-download-play="1" data-download-id="${esc(item.id)}" data-download-episode="${item.episode}" aria-label="播放第 ${item.episode} 集">${item.episode}</button>`;
      if (item.status === 'downloading') {
        const percent = Math.max(1, Math.min(99, Number(item.progress) || 0));
        return `<button type="button" class="download-chip busy" data-download-retry="${esc(item.key)}">${item.episode} ${percent}%</button>`;
      }
      if (item.status === 'queued')
        return `<button type="button" class="download-chip busy" data-download-retry="${esc(item.key)}">${item.episode}…</button>`;
      return `<button type="button" class="download-chip" data-download-retry="${esc(item.key)}" title="${esc(item.message || '点击重试')}">${item.episode}</button>`;
    }).join('');
    const more = !expanded && group.episodes.length > 12
      ? `<button type="button" class="download-chip more" data-download-expand="${esc(group.id)}">+${group.episodes.length - 12} 集</button>` : '';
    const active = group.episodes.find(item => item.status === 'downloading');
    const activeHint = active ? ` · 第 ${active.episode} 集 ${Math.max(1, Math.min(99, Number(active.progress) || 0))}%` : '';
    const exporting = state.exports && state.exports.title === group.title && state.exports.state && state.exports.state.indexOf('导出') === 0;
    const exportHint = exporting ? (state.exports.episode ? ` · ${state.exports.state} 第${state.exports.episode}集 ${state.exports.percent || 0}%` : ` · ${state.exports.state}`) : '';
    const doneSelected = group.episodes.filter(item => selectedKeys.has(item.key) && item.status === 'done').length;
    const selectBar = selecting ? `<div class="download-selectbar"><span>已选 ${selectedKeys.size} 集${doneSelected !== selectedKeys.size ? `（可导出 ${doneSelected}）` : ''}</span>
      <span class="download-select-actions">
        <button type="button" data-export-selected="1" ${doneSelected ? '' : 'disabled'}>导出</button>
        <button type="button" data-export-merge="1" ${doneSelected >= 2 ? '' : 'disabled'}>合并</button>
        <button type="button" class="danger" data-delete-selected="1" ${selectedKeys.size ? '' : 'disabled'}>删除</button>
        <button type="button" data-select-cancel="1">取消</button>
      </span></div>` : '';
    return `<div class="download-card"><div class="download-head"><span class="download-copy"><strong>${esc(group.title)}</strong><small>已下载 ${group.done}/${group.episodes.length} 集 · ${formatBytes(group.bytes)}${activeHint}${exportHint}</small></span>
      <span class="download-actions">${group.done > 0 ? `<button type="button" class="download-export" data-download-export="${esc(group.id)}" data-download-export-title="${esc(group.title)}">导出</button>` : ''}<button type="button" class="download-select" data-download-select="${esc(group.id)}">选择</button><button type="button" class="download-remove" data-download-remove-group="${esc(group.id)}">删除</button></span></div>
      <div class="download-chips">${chips}${more}</div>
      ${selectBar}
      ${group.done < group.episodes.length ? '<small class="download-legend">深色＝可离线播放 · 浅色虚线＝未完成，点一下继续下载 · 下载中显示百分比</small>' : '<small class="download-legend">导出为 MP4：手机“下载/HuangGuo/剧名/”下 · 已导出的文件不会重复生成</small>'}</div>`;
  }).join('')}</div>`;
}

function renderSettings() {
  content.innerHTML = `<div class="settings-page"><button type="button" class="listing-back" data-back="1">${icon('back')} 返回我的</button><h1>设置</h1>
    <section class="theme-settings"><h2>主题配色</h2><p>选择界面主色，立即生效。</p><div class="palette-row">${PALETTES.map(item => `<button type="button" class="palette-chip${paletteId() === item.id ? ' selected' : ''}" data-palette-pick="${item.id}" aria-pressed="${paletteId() === item.id}"><i></i><span>${item.name}</span></button>`).join('')}</div>${paletteId() === 'custom' ? customThemePanel() : ''}</section>
    <section class="settings-library"><h2>片单管理</h2><p>清空当前设备保存的片单。</p>
      <button type="button" data-clear="history" ${asArray(state.library?.progress).length ? '' : 'disabled'}>清空观看历史</button>
      <button type="button" data-clear="bookmarks" ${asArray(state.library?.bookmarks).length ? '' : 'disabled'}>清空我的收藏</button></section>
    <section class="update-settings"><div><h2>界面与站点资源</h2><p data-resource-status>后台自动检查，已下载的更新在合适时机启用。</p><button type="button" data-apply-resources hidden>启用已下载资源</button></div><button type="button" data-check-resources>检查资源</button></section>
    <section class="update-settings"><div><h2>应用更新</h2><button type="button" class="app-version ${updateAvailable ? 'has-update' : ''}" data-open-update aria-label="${updateAvailable ? `当前版本 ${esc(appVersion)}，发现新版 ${esc(updateAvailable.version)}，查看更新` : `当前版本 ${esc(appVersion)}，检查更新`}"><span class="app-version-text">版本 ${appVersion ? `v${esc(appVersion)}` : '读取中…'}</span></button><p>启动后自动检查，也可以在这里手动检查。</p></div><button type="button" data-check-update>检查更新</button></section>
    <section class="settings-storage"><h2>本地存储</h2><button type="button" data-clear="cache">清理内容缓存</button></section></div>`;
  api('hot-update-status').then(window.hgHotUpdateStatus).catch(() => {});
}

function customThemePanel() {
  const accent = customAccent();
  return `<div class="custom-theme">
    <div class="custom-theme-row"><span>主题色</span><input type="color" value="${accent}" data-accent-picker aria-label="选择主题色"></div>
    <div class="swatch-row">${ACCENT_SWATCHES.map(color => `<button type="button" data-accent-set="${color}" aria-label="使用 ${color}" style="background:${color}" class="${color.toLowerCase() === accent.toLowerCase() ? ' selected' : ''}"></button>`).join('')}</div>
    <div class="custom-theme-row"><span>底色</span><div class="custom-modes"><button type="button" data-custom-mode="light" class="${customDark() ? '' : 'selected'}">浅色底</button><button type="button" data-custom-mode="dark" class="${customDark() ? 'selected' : ''}">深色底</button></div></div>
  </div>`;
}

const MISS_AV_HISTORY = 'hg-missav-history';
function missAvHistory() {
  try { return asArray(JSON.parse(localStorage.getItem(MISS_AV_HISTORY) || '[]')); }
  catch (error) { return []; }
}
function missAvRemember(item) {
  if (!item?.id) return;
  const list = missAvHistory().filter(entry => entry.id !== item.id);
  list.unshift({ id: item.id, title: item.title, cover: item.cover, at: Date.now() });
  try { localStorage.setItem(MISS_AV_HISTORY, JSON.stringify(list.slice(0, 20))); } catch (error) { /* 仅本次生效 */ }
}
function missAvCard(item) {
  return `<button type="button" class="mv-card" data-mv-open="${esc(item.id)}" data-mv-cover="${esc(item.cover || '')}">
    <span class="mv-cover"><img src="${esc(item.cover || '')}" alt="" loading="lazy" referrerpolicy="no-referrer">${item.duration ? `<span class="mv-time">${esc(item.duration)}</span>` : ''}</span>
    <span class="mv-title">${esc(item.title)}</span></button>`;
}
function renderMissAvError(error) {
  content.innerHTML = `<div class="mv-page"><div class="mv-head"><h1>黄色仓库</h1></div>
    <div class="mv-state">${esc(error?.message || '加载失败')}<br><button type="button" data-mv-retry="1">重试</button></div></div>`;
}
const MISS_AV_SECTION_TYPES = {
  '最近更新': 'new', '新作上市': 'release', '无码影片': 'uncensored',
  '中文字幕': 'chinese', '今日热门': 'today', '本周热门': 'weekly', '本月热门': 'monthly'
};
const MISS_AV_DISCOVER = [
  { title: '热门榜单', items: [['today', '今日热门'], ['weekly', '本周热门'], ['monthly', '本月热门']] },
  { title: '新片与专题', items: [['new', '最近更新'], ['release', '新作上市'], ['uncensored', '无码流出'], ['chinese', '中文字幕'], ['vr', 'VR']] },
  { title: '服装', kind: 'search', items: [['制服', '制服'], ['OL', 'OL'], ['女仆', '女仆'], ['丝袜', '丝袜'], ['过膝袜', '过膝袜'], ['泳装', '泳装'], ['婚纱', '婚纱'], ['和服', '和服'], ['护士', '护士'], ['教师', '教师'], ['空姐', '空姐'], ['体操服', '体操服'], ['女高中生', '女高中生']] },
  { title: '剧情与关系', dynamic: 'plot', items: [] },
  { title: '主要片商', items: [['s1', 'S1'], ['moodyz', 'MOODYZ'], ['faleno', 'FALENO'], ['sod', 'SOD'], ['prestige', 'PRESTIGE']] },
  { title: '独立与无码厂牌', items: [['fc2', 'FC2'], ['siro', 'SIRO'], ['luxu', 'LUXU'], ['gana', 'GANA'], ['scute', 'S-CUTE'], ['heyzo', 'HEYZO'], ['tokyohot', '东京热'], ['1pondo', '一本道'], ['caribbeancom', 'Caribbeancom'], ['madou', '麻豆传媒'], ['twav', 'TWAV'], ['marriedslash', '人妻斩'], ['naughty4610', '顽皮 4610'], ['gachinco', 'Gachinco'], ['pacopacomama', 'pacopacomama'], ['10musume', '10musume']] }
];
async function loadMissAvActresses() {
  const host = content.querySelector('[data-mv-actress-host]');
  if (!host) return;
  try {
    const data = await api('missav-actresses');
    const items = asArray(data.items).slice(0, 12);
    host.innerHTML = items.map(item => `<button type="button" class="mv-actress" data-mv-actress="${esc(item.slug)}" data-mv-actress-name="${esc(item.name)}">
      <span class="mv-actress-rank">${item.rank}</span><img src="${esc(item.cover || '')}" alt="" referrerpolicy="no-referrer"><span>${esc(item.name)}</span></button>`).join('');
    host.querySelectorAll('[data-mv-actress]').forEach(button => button.addEventListener('click', () =>
      goMissAvList(button.dataset.mvActress, button.dataset.mvActressName, 1, false, 'actress')));
  } catch (error) {
    host.innerHTML = '<div class="mv-state">女优排行加载失败</div>';
  }
}
const MISS_AV_PLOT_GENRES = new Set(['剧情', 'NTR', '人妻', '熟女', '乱伦', '痴女', '搭讪', '恋物癖', '淫乱', '姐姐', '纪录片']);
async function loadMissAvGenres() {
  const host = content.querySelector('[data-mv-plot-host]');
  if (!host) return;
  try {
    const data = await api('missav-genres');
    const all = asArray(data.items);
    const plot = all.filter(item => MISS_AV_PLOT_GENRES.has(item.name));
    const items = plot.length ? plot : all.slice(0, 12);
    host.innerHTML = `${items.map(item => `<button type="button" class="mv-cat" data-mv-genre-path="${esc(item.path)}" data-mv-genre-name="${esc(item.name)}">${esc(item.name)}</button>`).join('')}
      <button type="button" class="mv-cat" data-mv-all-genres="1">全部类型 ›</button>`;
    host.querySelectorAll('[data-mv-genre-path]').forEach(button => button.addEventListener('click', () =>
      goMissAvList(button.dataset.mvGenrePath, button.dataset.mvGenreName, 1, false, 'genre')));
    const allButton = host.querySelector('[data-mv-all-genres]');
    if (allButton) allButton.addEventListener('click', goMissAvGenresPage);
  } catch (error) {
    host.innerHTML = '<div class="mv-state">类型加载失败</div>';
  }
}
async function goMissAvGenresPage() {
  ++routeToken;
  stopBannerAuto();
  setRoute('missav-genres'); state.tab = 'missav'; setNav('missav');
  content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button>
    <div class="mv-head"><h1>全部类型</h1><span class="mv-badge">站点索引</span></div>
    <div class="mv-discover" data-mv-all-host><div class="mv-state">正在加载…</div></div></div>`;
  try {
    const data = await api('missav-genres');
    const host = content.querySelector('[data-mv-all-host]');
    if (!host) return;
    const items = asArray(data.items);
    host.innerHTML = items.map(item => `<button type="button" class="mv-cat" data-mv-genre-path="${esc(item.path)}" data-mv-genre-name="${esc(item.name)}">${esc(item.name)}</button>`).join('');
    host.querySelectorAll('[data-mv-genre-path]').forEach(button => button.addEventListener('click', () =>
      goMissAvList(button.dataset.mvGenrePath, button.dataset.mvGenreName, 1, false, 'genre')));
  } catch (error) {
    const host = content.querySelector('[data-mv-all-host]');
    if (host) host.innerHTML = '<div class="mv-state">类型加载失败</div>';
  }
}
const HSCK_DISCOVER_GROUPS = [
  { title: '服装', items: ['制服', 'OL', '女仆', '丝袜', '泳装', '婚纱', '和服', '护士', '教师', '空姐', '女高中生'] },
  { title: '剧情与关系', items: ['NTR', '人妻', '熟女', '出轨', '乱伦', '痴女', '搭讪', '调教', '按摩', '恋物'] },
  { title: '片源与画质', items: ['无码', '中文字幕', '4K', '高清', '破解', '素人'] }
];
function renderMissAvDiscover(categories) {
  const list = asArray(categories);
  content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button>
    <div class="mv-head"><h1>栏目</h1><span class="mv-badge">黄色仓库</span></div>
    ${list.length ? `<div class="mv-section-head"><h2>全部分类</h2><span>${list.length} 类</span></div>
      <div class="mv-discover">${list.map(category => `<button type="button" class="mv-cat" data-mv-cat="${esc(category.id)}" data-mv-cat-title="${esc(category.name)}">${esc(category.name)}</button>`).join('')}</div>`
      : '<div class="mv-state">分类加载中…</div>'}
    ${HSCK_DISCOVER_GROUPS.map(group => `<div class="mv-section-head"><h2>${group.title}</h2><span>点词搜索</span></div>
      <div class="mv-discover">${group.items.map(word => `<button type="button" class="mv-cat" data-mv-search="${esc(word)}">${esc(word)}</button>`).join('')}</div>`).join('')}</div>`;
}
function goMissAvDiscover() {
  const token = ++routeToken;
  stopBannerAuto();
  setRoute('missav-discover'); state.tab = 'missav'; setNav('missav');
  const categories = asArray(state.missavHomeData?.categories);
  renderMissAvDiscover(categories);
  if (!categories.length) {
    api('missav-home', {}).then(data => {
      state.missavHomeData = data;
      if (token === routeToken && state.route === 'missav-discover') renderMissAvDiscover(asArray(data.categories));
    }).catch(error => {
      if (token === routeToken && state.route === 'missav-discover') renderMissAvError(error);
    });
  }
}
function renderMissAvHomeData(data) {
  const sections = asArray(data.sections).filter(section => asArray(section.items).length);
  const categories = asArray(data.categories);
  content.innerHTML = `<div class="mv-page"><div class="mv-head"><h1>黄色仓库</h1>
    <div class="mv-head-actions"><button type="button" class="mv-link" onclick="goMissAvFeed()">全部</button><button type="button" class="mv-link" onclick="goMissAvDiscover()">栏目</button></div></div>
    <div class="mv-cats">${categories.map(category => `<button type="button" class="mv-cat" data-mv-cat="${esc(category.id)}" data-mv-cat-title="${esc(category.name)}">${esc(category.name)}</button>`).join('')}</div>
    ${sections.map(section => `<div class="mv-section-head"><h2>${esc(section.title)}</h2><span>${asArray(section.items).length} 部</span></div>
      <div class="mv-row">${asArray(section.items).map(missAvCard).join('')}</div>`).join('')}</div>`;
  hydrateImages();
}
function missAvHomeSignature(data) {
  return asArray(data?.sections).map(section =>
    section.title + ':' + asArray(section.items).map(item => item.id).join(',')).join('|');
}
function renderMissAvListPage(list) {
  content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button>
    <div class="mv-head"><h1>${esc(list.title)}</h1><span class="mv-badge">${list.items.length} 部</span></div>
    ${list.items.length ? `<div class="mv-grid">${list.items.map(missAvCard).join('')}</div>` : '<div class="mv-state">没有内容</div>'}
    ${list.items.length && list.hasMore ? '<button type="button" class="mv-more-block" data-mv-list-more="1">加载更多</button>' : ''}</div>`;
  hydrateImages();
}
function renderMissAvFeedPage(feed) {
  content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button>
    <div class="mv-head"><h1>全部</h1><span class="mv-badge">${feed.items.length} 部</span></div>
    ${feed.items.length ? `<div class="mv-grid">${feed.items.map(missAvCard).join('')}</div>` : '<div class="mv-state">没有内容</div>'}
    ${feed.items.length && feed.hasMore ? '<button type="button" class="mv-more-block" data-mv-feed-more="1">加载更多</button>' : ''}</div>`;
  hydrateImages();
}
/** 从详情返回来源页：列表/全部/搜索回原页并恢复滚动，首页直接复用缓存。 */
function restoreMissAvReturn() {
  const back = state.missavReturn;
  if (!back || back.route === 'missav') { goMissAvHome(); return; }
  if (back.route === 'missav-list' && back.list) {
    ++routeToken;
    setRoute('missav-list'); state.tab = 'missav'; setNav('missav');
    state.missavList = back.list;
    renderMissAvListPage(back.list);
    scroll.scrollTop = back.scrollTop || 0;
    return;
  }
  if (back.route === 'missav-feed' && back.feed) {
    ++routeToken;
    setRoute('missav-feed'); state.tab = 'missav'; setNav('missav');
    state.missavFeed = back.feed;
    renderMissAvFeedPage(back.feed);
    scroll.scrollTop = back.scrollTop || 0;
    return;
  }
  goMissAvHome();
}

async function goMissAvHome() {
  const token = ++routeToken;
  stopBannerAuto();
  const returning = state.route === 'missav-detail' || state.route === 'missav-list'
    || state.route === 'missav-search' || state.route === 'missav-feed' || state.route === 'missav-discover';
  const restoreScroll = returning ? (state.missavHomeScroll || 0) : 0;
  setRoute('missav'); state.tab = 'missav'; setNav('missav');
  if (state.missavHomeData) {
    renderMissAvHomeData(state.missavHomeData);
    if (restoreScroll) scroll.scrollTop = restoreScroll;
  } else {
    content.innerHTML = `<div class="mv-page"><div class="mv-head"><h1>黄色仓库</h1></div><div class="mv-state">正在加载…</div></div>`;
  }
  // 首页数据 2 分钟内视为新鲜：返回首页只复用缓存，不再重新拉取和重绘。
  const fresh = state.missavHomeData
    && Date.now() - (state.missavHomeAt || 0) < 2 * 60 * 1000;
  if (fresh) return;
  try {
    const data = await api('missav-home', {});
    if (token !== routeToken || state.route !== 'missav') return;
    const changed = missAvHomeSignature(data) !== missAvHomeSignature(state.missavHomeData);
    const firstLoad = !state.missavHomeData;
    state.missavHomeData = data;
    state.missavHomeAt = Date.now();
    if (firstLoad || changed) {
      renderMissAvHomeData(data);
      scroll.scrollTop = restoreScroll;
    }
  } catch (error) {
    if (token === routeToken && !state.missavHomeData) renderMissAvError(error);
  }
}
async function goMissAvList(id, title, page = 1, append = false) {
  const token = ++routeToken;
  stopBannerAuto();
  if (!append) {
    setRoute('missav-list'); state.tab = 'missav'; setNav('missav');
    state.missavList = { id, title, items: [], page: 0, hasMore: true };
    content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button><div class="mv-head"><h1>${esc(title)}</h1></div><div class="mv-state">正在加载…</div></div>`;
  }
  try {
    const data = await api('missav-list', { id, page });
    if (token !== routeToken || state.route !== 'missav-list') return;
    const list = state.missavList || { id, title, items: [], page: 0, hasMore: true };
    const incoming = asArray(data.items);
    list.items = append ? [...list.items, ...incoming] : incoming;
    list.page = Number(data.page) || page;
    list.hasMore = !!data.hasMore;
    state.missavList = list;
    renderMissAvListPage(list);
  } catch (error) {
    if (token === routeToken && !append) renderMissAvError(error);
    else if (token === routeToken) toast(error.message || '加载失败', true);
  }
}
async function goMissAvArticles() {
  const token = ++routeToken;
  stopBannerAuto();
  setRoute('missav-articles'); state.tab = 'missav'; setNav('missav');
  content.innerHTML = `<div class="mv-page"><div class="mv-head"><h1>AV 影评</h1><span class="mv-badge">MissAV</span></div><div class="mv-state">正在加载…</div></div>`;
  try {
    const data = await api('missav-articles', { page: 1 });
    if (token !== routeToken) return;
    const items = asArray(data.items);
    content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button><div class="mv-head"><h1>AV 影评</h1><span class="mv-badge">${items.length} 篇</span></div>
      <div class="mv-art-grid">${items.map(item => `<button type="button" class="mv-art-card" data-mv-article="${esc(item.id)}">
        <span class="mv-cover"><img src="${esc(item.cover || '')}" alt="" loading="lazy" referrerpolicy="no-referrer"></span>
        <span class="mv-title">${esc(item.title)}</span>
        <span class="mv-meta">${esc(item.date || '')}</span></button>`).join('')}</div></div>`;
  } catch (error) {
    if (token === routeToken) renderMissAvError(error);
  }
}
async function goMissAvArticle(id) {
  const token = ++routeToken;
  stopBannerAuto();
  setRoute('missav-article'); state.tab = 'missav'; setNav('missav');
  content.innerHTML = `<div class="mv-detail"><div class="mv-state">正在加载…</div></div>`;
  try {
    const item = await api('missav-article', { id });
    if (token !== routeToken) return;
    const paragraphs = String(item.body || '').split(/\n{2,}/).filter(Boolean).map(text => `<p>${esc(text)}</p>`).join('');
    content.innerHTML = `<div class="mv-detail"><button type="button" class="mv-back" data-back="1">‹ 返回</button>${item.cover ? `<img class="mv-detail-cover" src="${esc(item.cover)}" alt="" referrerpolicy="no-referrer">` : ''}
      <h1>${esc(item.title)}</h1><div class="mv-meta">${esc(item.author || '')}${item.date ? ' · ' + esc(item.date) : ''}</div>
      <div class="mv-article">${paragraphs}</div></div>`;
  } catch (error) {
    if (token === routeToken) renderMissAvError(error);
  }
}
async function goMissAvFeed(page = 1, append = false) {
  const token = ++routeToken;
  stopBannerAuto();
  if (!append) {
    setRoute('missav-feed'); state.tab = 'missav'; setNav('missav');
    state.missavFeed = { items: [], page: 0, hasMore: true };
    content.innerHTML = `<div class="mv-page"><button type="button" class="mv-back" data-back="1">‹ 返回</button><div class="mv-head"><h1>全部</h1><span class="mv-badge">聚合</span></div><div class="mv-state">正在加载…</div></div>`;
  }
  try {
    const data = await api('missav-feed', { page });
    if (token !== routeToken || state.route !== 'missav-feed') return;
    const feed = state.missavFeed || { items: [], page: 0, hasMore: true };
    const incoming = asArray(data.items);
    feed.items = append ? [...feed.items, ...incoming] : incoming;
    feed.page = Number(data.page) || page;
    feed.hasMore = !!data.hasMore;
    state.missavFeed = feed;
    renderMissAvFeedPage(feed);
  } catch (error) {
    if (token === routeToken && !append) renderMissAvError(error);
    else if (token === routeToken) toast(error.message || '加载失败', true);
  }
}
async function goMissAvSearch(query) {
  const token = ++routeToken;
  stopBannerAuto();
  setRoute('missav-search'); state.tab = 'missav'; setNav('missav');
  content.innerHTML = `<div class="mv-page"><div class="mv-head"><h1>黄色仓库</h1><span class="mv-badge">搜索</span></div><div class="mv-state">正在搜索“${esc(query)}”…</div></div>`;
  try {
    const data = await api('missav-search', { query, page: 1 });
    if (token !== routeToken) return;
    const items = asArray(data.items);
    content.innerHTML = `<div class="mv-page"><div class="mv-head"><h1>搜索</h1><span class="mv-badge">${esc(query)}</span></div>
      ${items.length ? `<div class="mv-grid">${items.map(missAvCard).join('')}</div>` : '<div class="mv-state">没有找到内容</div>'}</div>`;
    hydrateImages();
  } catch (error) {
    if (token === routeToken) renderMissAvError(error);
  }
}
async function goMissAvDetail(id, cover = '') {
  const token = ++routeToken;
  stopBannerAuto();
  // 记住来源页与滚动位置，返回时回到原处而不是回首页顶部。
  if (state.route === 'missav') {
    state.missavHomeScroll = scroll.scrollTop;
    state.missavReturn = { route: 'missav' };
  } else if (state.route === 'missav-list' && state.missavList) {
    state.missavReturn = { route: 'missav-list', list: { ...state.missavList }, scrollTop: scroll.scrollTop };
  } else if (state.route === 'missav-feed' && state.missavFeed) {
    state.missavReturn = { route: 'missav-feed', feed: { ...state.missavFeed }, scrollTop: scroll.scrollTop };
  } else if (state.route === 'missav-search') {
    state.missavReturn = { route: 'missav-search', scrollTop: scroll.scrollTop };
  } else {
    state.missavReturn = { route: 'missav' };
  }
  setRoute('missav-detail'); state.tab = 'missav'; setNav('missav');
  content.innerHTML = `<div class="mv-detail"><div class="mv-state">正在加载…</div></div>`;
  try {
    const item = await api('missav-detail', { id });
    if (token !== routeToken || state.route !== 'missav-detail') return;
    if (!item.cover && cover) item.cover = cover;
    state.missavDetail = item;
    missAvRemember(item);
    content.innerHTML = `<div class="mv-detail"><button type="button" class="mv-back" data-back="1">‹ 返回</button>${item.cover ? `<img class="mv-detail-cover" src="${esc(item.cover)}" alt="" referrerpolicy="no-referrer">` : ''}
      <h1>${esc(item.title)}</h1>
      <p class="mv-desc">${esc(item.description || '')}</p>
      ${item.stream && item.page ? '<button type="button" class="mv-play" data-mv-play="1">立即播放</button>' : '<div class="mv-meta">暂无可用播放地址</div>'}
      <div class="mv-meta">片源：黄色仓库 · 18+</div></div>`;
  } catch (error) {
    if (token === routeToken) renderMissAvError(error);
  }
}

function renderSearch() {
  const filters = [['all', '全部'], ['ai-duanju', '成人短剧'], ['ai-manju', '成人漫剧'], ['ai-huanlian', 'AI换脸'], ['ai-mogai', 'AI魔改']];
  const all = asArray(state.search?.items);
  const items = state.filter === 'all' ? all : all.filter(item => {
    if (item.category) return item.category === state.filter;
    const title = String(item.title || '');
    if (state.filter === 'ai-huanlian') return /AI\s*换脸/.test(title);
    if (state.filter === 'ai-mogai') return /AI\s*魔改/.test(title);
    if (state.filter === 'ai-manju') return /漫剧/.test(title);
    return !/AI\s*(换脸|魔改)|漫剧/.test(title);
  });
  content.innerHTML = `<div class="search-page"><h1>搜索结果</h1><p>${esc(state.query)} · ${items.length} 部作品</p><div class="filter-row">${filters.map(([id, label]) => `<button type="button" data-filter="${id}" class="${state.filter === id ? 'active' : ''}">${label}</button>`).join('')}</div>
    ${items.length ? `<div class="search-grid">${items.map(itemCard).join('')}</div>` : '<div class="empty-state">没有找到匹配的影片</div>'}</div>`;
  hydrateImages();
}

function listingFooter() {
  const listing = state.listing;
  if (listing.error) return '<button type="button" data-retry-listing="1">加载失败，点击重试</button>';
  if (listing.loading) return '<span role="status">正在加载更多…</span>';
  if (listing.refreshing) return '<span role="status">正在更新列表…</span>';
  if (listing.nextPage) return listing.kind === 'tag-list' ? '<span class="listing-sentinel" aria-hidden="true"></span>' : '<span class="listing-sentinel">继续下滑加载更多</span>';
  return '<span>已经到底了</span>';
}

function observeListingEnd() {
  listingObserver?.disconnect();
  if (state.route !== 'listing' || !state.listing?.nextPage || state.listing.loading ||
      state.listing.refreshing || state.listing.error) return;
  const sentinel = content.querySelector('.listing-sentinel');
  if (!sentinel) return;
  if (!listingObserver) {
    listingObserver = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) loadMoreListing();
    }, { root: scroll, rootMargin: '0px 0px 320px 0px' });
  }
  listingObserver.observe(sentinel);
}

function updateListingFooter() {
  const footer = content.querySelector('.listing-footer');
  if (!footer) return;
  footer.innerHTML = listingFooter();
  observeListingEnd();
}

function renderListing() {
  const listing = state.listing;
  if (!listing?.items.length && listing?.refreshing) { renderSkeleton(); return; }
  const title = listing.kind === 'tag-list' ? `#${String(listing.label || listing.slug).replace(/^#+/, '')}` : listing.kind === 'recommend' ? '精选推荐' : '最近上新';
  const backLabel = listing.kind === 'tag-list' && state.listingReturn?.route === 'tags' ? '返回全部类型' : '返回首页';
  content.innerHTML = `<div class="listing-page"><button class="listing-back" type="button" data-back="1">${icon('back')} ${backLabel}</button>
    <h1>${esc(title)}</h1><p>已显示 ${listing.items.length} 部作品</p>
    ${listing.items.length ? `<div class="search-grid listing-grid">${listing.items.map(itemCard).join('')}</div>` : '<div class="empty-state">这个标签下暂无作品</div>'}
    <div class="listing-footer">${listingFooter()}</div></div>`;
  hydrateImages();
  observeListingEnd();
}

/** 详情页渲染输出的指纹；只覆盖 renderDetail 真正用到的字段。 */
function detailSignature(data, loading) {
  return [loading ? 'L' : 'R', data.id, data.title, data.score, data.episodeLabel,
    data.description || '', data.cover,
    asArray(data.episodes).map(item => item.number).join(',')].join('|');
}
let lastDetailSignature = '';

function renderDetail() {
  const data = state.detail;
  if (!data) { lastDetailSignature = ''; renderSkeleton(); return; }
  const loading = state.detailLoading;
  // 整页 innerHTML 重建会让封面 img 重新解码、闪一下。进入详情页时缓存与网络数据
  // 往往完全一致，内容没变就别重建（下载角标由 refreshDownloadBadges 单独刷新）。
  const signature = detailSignature(data, loading);
  if (signature === lastDetailSignature && content.querySelector('.detail-page')) return;
  lastDetailSignature = signature;
  window.AndroidHost?.setDetailMode?.(true);
  const episodes = asArray(data.episodes);
  content.innerHTML = `<div class="detail-page"><button class="detail-back" type="button" data-back="1">${icon('back')} 返回</button>
    <div class="detail-art"><img data-cover="${esc(data.cover)}" alt=""></div><div class="detail-copy"><h1>${esc(data.title)}</h1><p>${loading ? '正在获取内容…' : `${esc(data.score)} ${esc(data.episodeLabel)}`}</p><p class="detail-description">${esc(data.description || '')}</p>
    <div class="detail-buttons"><button class="detail-play" type="button" data-play="1" ${loading ? 'disabled' : ''}>${loading ? '正在加载…' : '立即播放'}</button><button class="bookmark-button" type="button" data-bookmark="1" aria-label="${state.bookmarked ? '取消收藏' : '收藏'}" ${loading ? 'disabled' : ''}>${state.bookmarked ? '★' : '☆'}</button></div>
    ${loading ? '<div class="detail-loading" role="status">正在获取选集…</div>' : episodes.length ? `<div class="episode-head"><h2>选集</h2><button type="button" class="download-all" data-download-all="1">下载整部</button></div><div class="episode-grid">${episodes.map((item, index) => `<button type="button" data-episode="${item.number}" class="ep-cell ${index === 0 ? 'active' : ''}"><span class="ep-number">${item.number}</span><span class="ep-dl${downloadInfo(data.id, item.number)?.status === 'done' ? ' has' : ''}${downloadInfo(data.id, item.number)?.status === 'downloading' || downloadInfo(data.id, item.number)?.status === 'queued' ? ' busy' : ''}" data-download-ep="${item.number}" role="button" aria-label="下载第 ${item.number} 集">${downloadBadge(downloadInfo(data.id, item.number))}</span></button>`).join('')}</div>` : ''}</div></div>`;
  hydrateImages();
}

/** 收藏状态只影响一个按钮，就地改写，避免整页重建导致封面闪烁。 */
function applyBookmarkState(saved, expectedId) {
  // 异步返回期间可能已经切到别的剧，别把星标记到当前这部上。
  if (expectedId != null && state.detail?.id !== expectedId) return;
  state.bookmarked = saved;
  const button = content.querySelector('.bookmark-button');
  if (!button) return;   // 页面尚未渲染，随后的 renderDetail 会带上最新状态
  button.textContent = saved ? '★' : '☆';
  button.setAttribute('aria-label', saved ? '取消收藏' : '收藏');
}

function renderSkeleton() {
  content.innerHTML = '<div class="skeleton-home" role="status" aria-label="正在加载内容"><div class="skeleton skeleton-hero"></div><div class="skeleton skeleton-title"></div><div class="skeleton-row"><div class="skeleton skeleton-poster"></div><div class="skeleton skeleton-poster"></div><div class="skeleton skeleton-poster"></div></div><div class="skeleton skeleton-line"></div></div>';
}
function renderError(error, retry) {
  if (state.route === 'detail') window.AndroidHost?.setDetailMode?.(false);
  if (/站点连接失败|站点请求失败|failed to connect|unable to resolve host|unknownhost|connectexception|sockettimeoutexception|timed? out|network is unreachable|connection reset|connection refused|网络|连接失败|无法连接/i.test(error?.message || '')) {
    content.innerHTML = `<div class="error-state error-state--network" role="alert">
      <div class="error-main">
        <svg class="error-icon" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="24" cy="24" r="21"/><path d="m12 24 6-5 6 5 6-5 6 5"/></svg>
        <h1>网络走丢了</h1>
      </div>
      <div class="error-footer"><p>请尝试使用代理网络，或联系开发者。</p><button type="button" data-retry="${esc(retry)}">重新尝试</button></div>
    </div>`;
    return;
  }
  content.innerHTML = `<div class="error-state">${esc(error.message || '加载失败，请稍后重试')}<button type="button" data-retry="${esc(retry)}">重试</button></div>`;
}

function rememberScreen() {
  if (state.route === 'detail') return;
  const previewContent = content.cloneNode(true);
  previewContent.removeAttribute('id');
  screenSnapshots[state.route] = {
    content: previewContent, scrollTop: scroll.scrollTop,
    horizontalScroll: [...content.querySelectorAll('.film-row,.filter-row,.home-tag-scroll')].map(row => row.scrollLeft)
  };
}
function captureScreen() {
  rememberScreen();
  return {
    route: state.route, tab: state.tab, pageNode: content.firstElementChild,
    scrollTop: scroll.scrollTop, searchValue: searchInput.value,
    listing: state.route === 'listing' ? state.listing : null,
    listingReturn: state.listingReturn, tagsReturn: state.tagsReturn,
    compactHeld: state.compactHeld,
    horizontalScroll: [...content.querySelectorAll('.film-row,.filter-row,.home-tag-scroll')].map(row => row.scrollLeft)
  };
}
function restoreScreen(snapshot) {
  if (!snapshot?.pageNode) { goHome(); return; }
  ++routeToken;
  listingObserver?.disconnect();
  categoryObserver?.disconnect();
  setRoute(snapshot.route);
  state.tab = snapshot.tab;
  state.compactHeld = snapshot.compactHeld;
  if (snapshot.listing) state.listing = snapshot.listing;
  state.listingReturn = snapshot.listingReturn;
  state.tagsReturn = snapshot.tagsReturn;
  content.replaceChildren(snapshot.pageNode);
  if (snapshot.route === 'library') renderLibrary();
  if (snapshot.route === 'settings') renderSettings();
  searchInput.value = snapshot.searchValue || '';
  document.querySelectorAll('#dock [data-nav]').forEach(button => button.classList.toggle('active', button.dataset.nav === state.tab));
  scroll.scrollTop = snapshot.scrollTop || 0;
  content.querySelectorAll('.film-row,.filter-row,.home-tag-scroll').forEach((row, index) => {
    row.scrollLeft = snapshot.horizontalScroll?.[index] || 0;
  });
  hydrateImages();
  if (snapshot.route === 'home') scheduleBannerAuto();
  if (snapshot.route === 'category') { compact.innerHTML = compactMarkup(); updateCompact(); observeCategoryEnd(); }
  if (snapshot.route === 'listing') observeListingEnd();
}

function setRoute(route) {
  if (route !== 'home') stopBannerAuto();
  if (state.route === 'detail' && route !== 'detail') { detailCard?.dispose(); detailCard = null; }
  const libraryArea = ['library', 'settings'].includes(route);
  if (state.route === 'library' && route !== 'library') searchInput.value = '';
  state.route = route;
  window.hgScheduleResourceApply?.();
  document.getElementById('app').dataset.route = route;
  window.hgThemeRefresh?.();
  document.getElementById('app').classList.toggle('route-detail', route === 'detail');
  window.AndroidHost?.setDetailMode?.(route === 'detail');
  headerSettings.hidden = route !== 'library';
  const missAvArea = route === 'missav' || route === 'missav-detail' || route === 'missav-list' || route === 'missav-search' || route === 'missav-feed';
  searchInput.placeholder = missAvArea ? '搜索仓库' : libraryArea ? '搜索观看历史和收藏' : '搜索剧名或 #标签';
  searchInput.setAttribute('aria-label', missAvArea ? '搜索仓库' : libraryArea ? '搜索观看历史和收藏' : '搜索剧名或标签');
  if (route === 'library') searchInput.value = state.libraryQuery;
  window.AndroidHost?.setBackEnabled(route !== 'home');
}

function backDestination() {
  if (state.route === 'post') return 'chigua';
  if (state.route === 'topic') return 'home';
  if (state.route === 'campaign') return state.campaignReturn?.route || 'home';
  if (state.route === 'detail') return state.previous?.route || 'home';
  if (state.route === 'settings') return state.settingsReturn?.route || 'library';
  if (state.route === 'tags') return state.tagsReturn?.route || 'home';
  if (state.route === 'listing' && state.listing?.kind === 'tag-list') return state.listingReturn?.route || 'home';
  return state.route === 'home' ? null : 'home';
}

function clearPredictivePreview() {
  clearTimeout(predictiveTimer);
  if (predictiveFrame) cancelAnimationFrame(predictiveFrame);
  predictiveFrame = null;
  if (predictiveSourceNode && predictivePreview?.contains(predictiveSourceNode)) predictiveSourceNode.remove();
  predictiveSourceNode = null;
  predictivePreview?.remove();
  predictivePreview = null;
  document.getElementById('app').classList.remove('predictive-active');
  scroll.style.removeProperty('transition');
  scroll.style.removeProperty('transform');
}

window.hgPredictiveBackStart = fromRight => {
  clearPredictivePreview();
  if (state.route === 'detail' && detailCard && confirmOverlay.hidden && updateOverlay.hidden) {
    detailCard.fromRight = fromRight;
    return detailCard.begin();
  }
  const destination = backDestination();
  const fromDetail = state.route === 'detail' && state.previous?.route === destination && state.previous.pageNode;
  const snapshot = fromDetail ? state.previous : screenSnapshots[destination];
  if (!snapshot) return false;
  const preview = document.createElement('div');
  preview.className = 'back-preview';
  preview.setAttribute('aria-hidden', 'true');
  if (state.route === 'detail') {
    const header = document.querySelector('#app > .app-top').cloneNode(true);
    const settings = header.querySelector('.header-settings');
    settings.hidden = destination !== 'library';
    if (destination === 'library') {
      const input = header.querySelector('.search-input');
      input.placeholder = '搜索观看历史和收藏';
      input.value = state.libraryQuery;
    }
    header.querySelectorAll('[id]').forEach(node => node.removeAttribute('id'));
    preview.appendChild(header);
  }
  if (fromDetail) {
    const holder = document.createElement('div');
    holder.style.transform = `translateY(${-snapshot.scrollTop}px)`;
    predictiveSourceNode = snapshot.pageNode;
    holder.appendChild(predictiveSourceNode);
    preview.appendChild(holder);
  } else {
    predictiveSourceNode = snapshot.content;
    predictiveSourceNode.style.transform = `translateY(${-snapshot.scrollTop}px)`;
    preview.appendChild(predictiveSourceNode);
  }
  document.getElementById('app').appendChild(preview);
  preview.querySelectorAll('.film-row,.filter-row,.home-tag-scroll').forEach((row, index) => {
    row.scrollLeft = snapshot.horizontalScroll?.[index] || 0;
  });
  document.getElementById('app').classList.add('predictive-active');
  scroll.style.transition = 'none';
  predictivePreview = preview;
  predictivePreview.fromRight = fromRight;
  return true;
};

window.hgPredictiveBackProgress = progress => {
  if (state.route === 'detail' && detailCard?.phase === 'dragging') {
    detailCard.predictive(Math.max(0, Math.min(1, progress)), detailCard.fromRight);
    return;
  }
  if (!predictivePreview) return;
  pendingPredictiveProgress = Math.max(0, Math.min(1, progress));
  if (predictiveFrame) return;
  predictiveFrame = requestAnimationFrame(() => {
    predictiveFrame = null;
    if (!predictivePreview) return;
    const direction = predictivePreview.fromRight ? -1 : 1;
    scroll.style.transform = `translate3d(${direction * pendingPredictiveProgress * 100}%,0,0)`;
  });
};

window.hgPredictiveBackCancel = () => {
  if (state.route === 'detail' && detailCard?.phase === 'dragging') { detailCard.cancel(); return; }
  if (!predictivePreview) return;
  if (predictiveFrame) cancelAnimationFrame(predictiveFrame);
  predictiveFrame = null;
  scroll.style.transition = 'transform 180ms ease-out';
  scroll.style.transform = 'translate3d(0,0,0)';
  predictiveTimer = setTimeout(clearPredictivePreview, 180);
};

window.hgPredictiveBackCommit = () => {
  if (state.route === 'detail' && detailCard && confirmOverlay.hidden && updateOverlay.hidden) {
    detailCard.close(); return true;
  }
  if (!predictivePreview) return window.hgBack();
  if (predictiveFrame) cancelAnimationFrame(predictiveFrame);
  predictiveFrame = null;
  const direction = predictivePreview.fromRight ? -1 : 1;
  scroll.style.transition = 'transform 150ms ease-out';
  scroll.style.transform = `translate3d(${direction * 100}%,0,0)`;
  predictiveTimer = setTimeout(() => {
    const oldPage = content.firstElementChild;
    if (!window.hgBack()) { clearPredictivePreview(); return; }
    if (content.firstElementChild !== oldPage) { clearPredictivePreview(); return; }
    const changed = new MutationObserver(() => {
      if (content.firstElementChild === oldPage) return;
      changed.disconnect();
      clearPredictivePreview();
    });
    changed.observe(content, { childList: true });
    predictiveTimer = setTimeout(() => { changed.disconnect(); clearPredictivePreview(); }, 1500);
  }, 150);
  return true;
};

function setNav(tab) {
  listingObserver?.disconnect();
  categoryObserver?.disconnect();
  document.querySelectorAll('#dock [data-nav]').forEach(button => button.classList.toggle('active', button.dataset.nav === tab));
  compact.classList.remove('visible');
  compact.inert = true;
  state.compactHeld = false;
  scroll.scrollTop = 0;
}

async function goHome() {
  const token = ++routeToken;
  stopBannerAuto();
  setRoute('home'); state.tab = 'home'; setNav('home');
  const refreshing = api('home');
  const cached = await api('cached', { key: 'home' }).catch(() => null);
  if (token !== routeToken) return;
  state.home = cached?.data || null;
  if (state.home) renderHome(); else renderSkeleton();
  try {
    const fresh = await refreshing;
    if (token !== routeToken) return;
    const changed = state.home && homeSignature(state.home) !== homeSignature(fresh);
    const firstLoad = !state.home;
    state.home = fresh;
    if (firstLoad || changed) renderHome();
    else refreshMissingImages([...asArray(fresh.featured), ...asArray(fresh.recommend?.items), ...asArray(fresh.newest?.items)]);
    if (changed) toast('更新成功');
  } catch (error) { if (!state.home && token === routeToken) renderError(error, 'home'); }
}

async function goTags() {
  const token = ++routeToken;
  if (state.route !== 'tags') state.tagsReturn = captureScreen();
  setRoute('tags'); state.tab = 'home'; setNav('home');
  const refreshing = api('tags');
  const cached = await api('cached', { key: 'tags' }).catch(() => null);
  if (token !== routeToken) return;
  state.tags = cached?.data || state.tags;
  if (state.tags) renderTags(); else renderSkeleton();
  try {
    const fresh = await refreshing;
    if (token !== routeToken) return;
    const changed = JSON.stringify(state.tags?.items) !== JSON.stringify(fresh.items);
    const previousScroll = scroll.scrollTop;
    state.tags = fresh;
    if (changed) { renderTags(); scroll.scrollTop = previousScroll; }
  } catch (error) { if (token === routeToken && !state.tags) renderError(error, 'tags'); }
}

async function goTag(slug, label) {
  const token = ++routeToken;
  if (state.route !== 'listing' || state.listing?.kind !== 'tag-list' || state.listing?.slug !== slug) state.listingReturn = captureScreen();
  setRoute('listing'); state.tab = 'home'; setNav('home');
  searchInput.value = `#${String(label).replace(/^#+/, '')}`;
  const refreshing = api('tag-list', { slug, page: 1 });
  const cached = await api('cached', { key: `tag:${slug}:1` }).catch(() => null);
  if (token !== routeToken) return;
  const firstLoad = !cached?.data;
  state.listing = cached?.data ? { ...cached.data, kind: 'tag-list', slug, label, refreshing: true, loading: false, error: false } :
    { items: [], nextPage: null, kind: 'tag-list', slug, label, refreshing: true, loading: false, error: false };
  renderListing();
  try {
    const fresh = await refreshing;
    if (token !== routeToken) return;
    const changed = listSignature(state.listing) !== listSignature(fresh) || state.listing.nextPage !== fresh.nextPage;
    const previousScroll = scroll.scrollTop;
    state.listing = { ...fresh, kind: 'tag-list', slug, label, refreshing: false, loading: false, error: false };
    if (firstLoad || changed) { renderListing(); scroll.scrollTop = previousScroll; }
    else updateListingFooter();
  } catch (error) {
    if (token !== routeToken) return;
    if (!state.listing.items.length) renderError(error, 'tag-list');
    else { state.listing.refreshing = false; updateListingFooter(); toast('列表更新失败，已显示缓存内容', true); }
  }
}

async function goTagQuery(query) {
  const name = query.replace(/^[#＃]\s*/, '').trim();
  if (!name) { goTags(); return; }
  let tags = asArray(state.tags?.items);
  if (!tags.length) {
    const cached = await api('cached', { key: 'tags' }).catch(() => null);
    tags = asArray(cached?.data?.items);
  }
  if (!tags.length) {
    try { const fresh = await api('tags'); state.tags = fresh; tags = asArray(fresh.items); }
    catch { toast('标签暂时无法加载，请重试', true); return; }
  }
  const normalize = value => String(value || '').replace(/^#+/, '').trim().toLocaleLowerCase();
  let tag = tags.find(item => normalize(item.name) === normalize(name));
  if (!tag) {
    try { const fresh = await api('tags'); state.tags = fresh; tag = asArray(fresh.items).find(item => normalize(item.name) === normalize(name)); }
    catch { /* 已有清单仍可用于搜索 */ }
  }
  if (tag) goTag(tag.slug, tag.name);
  else toast('没有找到这个标签', true);
}

async function openListing(kind) {
  if (kind !== 'recommend' && kind !== 'newest') return;
  const token = ++routeToken;
  rememberScreen();
  listingObserver?.disconnect();
  setRoute('listing'); state.tab = 'home';
  setNav('home');
  const initial = state.home?.[kind];
  state.listing = {
    kind, items: [...asArray(initial?.items)], nextPage: initial?.nextPage || null,
    refreshing: true, loading: false, error: false
  };
  renderListing();
  try {
    const fresh = await api(kind, { page: 1 });
    if (token !== routeToken) return;
    state.listing.items = asArray(fresh.items);
    state.listing.nextPage = fresh.nextPage;
    state.listing.refreshing = false;
    const previousScroll = scroll.scrollTop;
    renderListing();
    scroll.scrollTop = previousScroll;
  } catch (error) {
    if (token !== routeToken) return;
    state.listing.refreshing = false;
    if (!state.listing.items.length) renderError(error, 'listing');
    else { updateListingFooter(); toast('列表更新失败，已显示缓存内容', true); }
  }
}

async function loadMoreListing() {
  const listing = state.listing;
  if (state.route !== 'listing' || !listing?.nextPage || listing.refreshing || listing.loading || listing.error) return;
  const token = routeToken;
  const pageNumber = listing.nextPage;
  listing.loading = true;
  updateListingFooter();
  try {
    const page = await api(listing.kind, { page: pageNumber, slug: listing.slug });
    if (token !== routeToken || state.listing !== listing || state.route !== 'listing') return;
    const known = new Set(listing.items.map(item => String(item.id)));
    const added = asArray(page.items).filter(item => {
      const id = String(item.id);
      if (known.has(id)) return false;
      known.add(id);
      return true;
    });
    listing.items.push(...added);
    listing.nextPage = page.items?.length && page.nextPage > pageNumber ? page.nextPage : null;
    const grid = content.querySelector('.listing-grid');
    if (grid && added.length) {
      grid.insertAdjacentHTML('beforeend', added.map(itemCard).join(''));
      const images = [...grid.querySelectorAll('img[data-cover]')].slice(-added.length);
      images.forEach((image, index) => index < 8 ? loadCoverInto(image) : observer.observe(image));
    }
    const count = content.querySelector('.listing-page > p');
    if (count) count.textContent = `已显示 ${listing.items.length} 部作品`;
  } catch (error) {
    if (token === routeToken && state.listing === listing && state.route === 'listing') listing.error = true;
  } finally {
    listing.loading = false;
    if (state.listing === listing && state.route === 'listing') updateListingFooter();
  }
}

async function goCategory(tab, sub = state.sub[tab], keepCompact = false) {
  const token = ++routeToken;
  categoryObserver?.disconnect();
  if (state.route === 'home') rememberScreen();
  setRoute('category'); state.tab = tab; state.sub[tab] = sub; state.category = null;
  if (!keepCompact) setNav(tab);
  const id = categoryId();
  const refreshing = api('category', { id, page: 1 });
  const cached = await api('cached', { key: `category:${id}:1` }).catch(() => null);
  if (token !== routeToken) return;
  state.category = cached?.data ? { ...cached.data, refreshing: true, loading: false, error: false } : null;
  if (state.category) renderCategory(keepCompact); else renderSkeleton();
  try {
    const fresh = await refreshing;
    if (token !== routeToken) return;
    const changed = state.category && listSignature(state.category) !== listSignature(fresh);
    const firstLoad = !state.category;
    const previousScroll = scroll.scrollTop;
    state.category = { ...fresh, refreshing: false, loading: false, error: false };
    state.categoryItems = asArray(fresh.items);
    if (firstLoad || changed) {
      renderCategory(keepCompact || state.compactHeld);
      if (!firstLoad) scroll.scrollTop = previousScroll;
    } else {
      refreshMissingImages(asArray(fresh.items));
      updateCategoryFooter();
    }
    if (changed) toast('更新成功');
  } catch (error) {
    if (token !== routeToken) return;
    if (!state.category) renderError(error, 'category');
    else { state.category.refreshing = false; updateCategoryFooter(); toast('列表更新失败，已显示缓存内容', true); }
  }
}

async function goLibrary(tab = 'history') {
  const token = ++routeToken;
  if (state.route === 'home') rememberScreen();
  state.libraryTab = tab;
  setRoute('library'); state.tab = 'library'; setNav('library'); renderSkeleton();
  try { state.library = await api('library'); state.downloads = await api('downloads'); state.postBookmarks = await api('post-bookmarks'); if (token === routeToken) renderLibrary(); }
  catch (error) { if (token === routeToken) renderError(error, 'library'); }
}

function goSettings() {
  state.settingsReturn = captureScreen();
  setRoute('settings'); state.tab = 'library'; setNav('library');
  renderSettings();
}

async function goSearch(query) {
  const token = ++routeToken;
  if (state.route === 'home') rememberScreen();
  state.previous = { route: state.route, tab: state.tab };
  setRoute('search'); state.query = query.trim(); state.filter = 'all'; state.search = null;
  const refreshing = api('search', { query: state.query });
  const cached = await api('cached', { key: `search:${state.query}` }).catch(() => null);
  if (token !== routeToken) return;
  state.search = cached?.data || null;
  if (state.search) renderSearch(); else renderSkeleton();
  try { const fresh = await refreshing; if (token === routeToken) { state.search = fresh; renderSearch(); } }
  catch (error) { if (!state.search && token === routeToken) renderError(error, 'search'); }
}

function sourceItem(id) {
  const candidates = [state.listing?.items, state.home?.featured, state.home?.homepageRecommend, state.home?.homepageNewest, state.home?.recommend?.items, state.home?.newest?.items, state.category?.items, state.search?.items, state.library?.bookmarks, state.library?.progress].flatMap(asArray);
  return candidates.find(item => item.id === id) || { id, title: `剧集 ${id}` };
}
async function goDetail(id, trigger) {
  if (state.route === 'detail' && state.sourceItem?.id === id) {
    // Retry in place; preserve the original source card and return destination.
    state.detailLoading = true; renderDetail();
    const token = ++routeToken;
    try { const fresh = await api('detail', { id }); if (token === routeToken) { state.detail = fresh; state.detailLoading = false; renderDetail(); } }
    catch (error) { if (token === routeToken) { state.detailLoading = false; renderError(error, 'detail'); } }
    return;
  }
  const token = ++routeToken;
  const entrySource = bannerChanging && trigger?.closest('.hero') ? null : HGCardTransition.capture(trigger);
  rememberScreen();
  state.previous = {
    route: state.route, tab: state.tab, sub: state.sub[state.tab], query: state.query,
    filter: state.filter, scrollTop: scroll.scrollTop, compactHeld: state.compactHeld,
    horizontalScroll: [...content.querySelectorAll('.film-row,.filter-row,.home-tag-scroll')].map(row => row.scrollLeft),
    pageNode: content.firstElementChild
  };
  if (state.route === 'listing' && state.listing) state.listing.refreshing = false;
  listingObserver?.disconnect();
  categoryObserver?.disconnect();
  state.sourceItem = sourceItem(id);
  state.sourceGroup = state.route === 'category' ? categoryId() : state.sourceItem.category || '';
  const aiGroup = state.sourceGroup === 'ai-huanlian' || state.sourceGroup === 'ai-mogai';
  const candidates = state.route === 'category' ? asArray(state.category?.items) : state.route === 'search' ? asArray(state.search?.items) : state.route === 'listing' ? asArray(state.listing?.items) :
    [...asArray(state.home?.recommend?.items), ...asArray(state.home?.newest?.items)];
  state.sourceQueue = aiGroup ? candidates.filter(item => item.category === state.sourceGroup) : [];
  setRoute('detail'); state.detail = { ...state.sourceItem }; state.detailLoading = true; state.bookmarked = false;
  scroll.scrollTop = 0;
  updateCompact();
  renderDetail();
  if (entrySource) {
    detailCard = new HGCardTransition({
      app: document.getElementById('app'), scroll, content, source: entrySource, snapshot: state.previous,
      isDetail: () => state.route === 'detail',
      onClose: () => { returnFromDetail(); trigger?.focus({ preventScroll: true }); }
    });
    detailCard.open();
  }
  const refreshing = api('detail', { id });
  const cached = await api('cached', { key: `detail:${id}` }).catch(() => null);
  if (token !== routeToken) return;
  let hasDetailData = Boolean(cached?.data);
  if (hasDetailData) { state.detail = cached.data; state.detailLoading = false; renderDetail(); }
  api('bookmark-state', { id }).then(saved => { if (token === routeToken) applyBookmarkState(saved); }).catch(() => {});
  api('downloads').then(list => { if (token === routeToken) { state.downloads = list; refreshDownloadBadges(); } }).catch(() => {});
  try { const fresh = await refreshing; if (token === routeToken) { state.detail = fresh; state.detailLoading = false; renderDetail(); } }
  catch (error) { if (!hasDetailData && token === routeToken) { state.detailLoading = false; renderError(error, 'detail'); } }
}

function returnFromDetail() {
  const previous = state.previous || { route: 'home', tab: 'home' };
  if (!previous.pageNode) { goHome(); return; }
  ++routeToken;
  setRoute(previous.route);
  state.tab = previous.tab;
  if (previous.route === 'category') state.sub[previous.tab] = previous.sub;
  state.query = previous.query || '';
  state.filter = previous.filter || 'all';
  state.compactHeld = previous.compactHeld;
  content.replaceChildren(previous.pageNode);
  state.previous = null;
  content.querySelectorAll('.film-row,.filter-row,.home-tag-scroll').forEach((row, index) => {
    row.scrollLeft = previous.horizontalScroll?.[index] || 0;
  });
  document.querySelectorAll('#dock [data-nav]').forEach(button =>
    button.classList.toggle('active', button.dataset.nav === state.tab));
  scroll.scrollTop = previous.scrollTop || 0;
  if (previous.route === 'category') compact.innerHTML = compactMarkup();
  updateCompact();
  hydrateImages();
  if (previous.route === 'category') observeCategoryEnd();
  if (previous.route === 'listing') observeListingEnd();
  if (previous.route === 'home') scheduleBannerAuto();
}

window.hgBack = () => {
  if (!confirmOverlay.hidden) { closeConfirmation(false); return true; }
  if (!updateOverlay.hidden) { if (!updateDownloading) updateOverlay.hidden = true; return true; }
  if (state.route === 'missav-detail') { restoreMissAvReturn(); return true; }
  if (state.route === 'missav-search' || state.route === 'missav-list' || state.route === 'missav-discover' || state.route === 'missav-feed') { goMissAvHome(); return true; }
  if (state.route === 'campaign') { restoreScreen(state.campaignReturn); return true; }
  if (state.route === 'settings') { restoreScreen(state.settingsReturn); return true; }
  if (state.route === 'detail') { if (detailCard) detailCard.close(); else returnFromDetail(); return true; }
  if (state.route === 'listing' && state.listing?.kind === 'tag-list') { restoreScreen(state.listingReturn); return true; }
  if (state.route === 'post') { restoreScreen(state.postReturn); return true; }
  if (state.route === 'topic') { restoreScreen(state.topicReturn); return true; }
  if (state.route === 'tags') { restoreScreen(state.tagsReturn); return true; }
  if (state.route === 'listing') { goHome(); return true; }
  if (state.route === 'search') { searchInput.value = ''; goHome(); return true; }
  if (state.route !== 'home') { goHome(); return true; }
  return false;
};
window.hgResume = () => {
  window.hgRefreshPendingResources?.();
  window.hgThemeRefresh?.();
  retryFailedImages(true);
  if (state.route === 'library') goLibrary(state.libraryTab);
  if (state.route === 'detail' && state.detail) {
    const id = state.detail.id;
    api('bookmark-state', { id }).then(saved => applyBookmarkState(saved, id));
  }
};

async function openPlayer(episode = 1) {
  const detail = state.detail;
  if (!detail) return;
  const item = { ...state.sourceItem, ...detail };
  const queue = state.sourceQueue.length ? [...state.sourceQueue] : [item];
  if (!queue.some(candidate => candidate.id === item.id)) queue.unshift(item);
  const index = queue.findIndex(candidate => candidate.id === item.id);
  await api('open-player', { item, detail, episodes: asArray(detail.episodes), queue, index, group: state.sourceGroup, episode });
}

async function loadMoreCategory() {
  const category = state.category;
  if (state.route !== 'category' || !category?.nextPage || category.loading || category.refreshing || category.error) return;
  const token = routeToken;
  const next = category.nextPage;
  const id = categoryId();
  category.loading = true;
  updateCategoryFooter();
  try {
    const page = await api('category', { id, page: next });
    if (token !== routeToken || state.category !== category || state.route !== 'category' || categoryId() !== id) return;
    const existing = new Set(asArray(category.items).map(item => String(item.id)));
    const added = asArray(page.items).filter(item => {
      const itemId = String(item.id);
      if (existing.has(itemId)) return false;
      existing.add(itemId);
      return true;
    });
    category.items.push(...added);
    category.nextPage = page.items?.length && page.nextPage > next ? page.nextPage : null;
    const grid = content.querySelector('.category-grid');
    if (grid && added.length) {
      grid.insertAdjacentHTML('beforeend', added.map(itemCard).join(''));
      [...grid.querySelectorAll('img[data-cover]')].slice(-added.length)
        .forEach((image, index) => index < 8 ? loadCoverInto(image) : observer.observe(image));
    }
    const count = content.querySelector('.category-count');
    if (count) count.textContent = `已显示 ${category.items.length} 部`;
  } catch (error) {
    if (token === routeToken && state.category === category && state.route === 'category') category.error = true;
  } finally {
    category.loading = false;
    if (state.category === category && state.route === 'category') updateCategoryFooter();
  }
}

document.getElementById('search-form').addEventListener('submit', event => {
  event.preventDefault();
  const query = searchInput.value.trim();
  searchInput.blur();
  if (['library', 'settings'].includes(state.route)) {
    state.libraryQuery = query;
    if (state.route === 'library') renderLibrary();
    else goLibrary(state.libraryTab);
    scroll.scrollTop = 0;
    return;
  }
  if (state.route === 'missav' || state.route === 'missav-detail' || state.route === 'missav-list' || state.route === 'missav-search' || state.route === 'missav-feed') {
    if (query) goMissAvSearch(query);
    return;
  }
  if (/^[#＃]/.test(query)) goTagQuery(query);
  else if (query) goSearch(query);
});
searchInput.addEventListener('input', () => {
  if (state.route !== 'library') return;
  state.libraryQuery = searchInput.value;
  renderLibrary();
  scroll.scrollTop = 0;
});

document.addEventListener('submit', async event => {
  if (event.target.id !== 'password-form') return;
  event.preventDefault();
});

function navigateDock(tab) {
  if (state.route === 'detail') state.previous = null;
  if (tab === 'home') goHome();
  else if (tab === 'library') goLibrary();
  else if (tab === 'chigua') goChigua(state.chigua?.channel || 'all');
  else if (tab === 'missav') goMissAvHome();
  else goCategory(tab);
}

function tapDock(button) {
  const tab = button.dataset.nav;
  const now = performance.now();
  if (lastDockTap.tab === tab && now - lastDockTap.at < 320) {
    const alreadyNavigated = lastDockTap.navigated;
    lastDockTap = { tab: '', at: 0, navigated: false };
    const icon = button.querySelector('.nav-icon');
    icon?.classList.remove('dock-bounce');
    void icon?.offsetWidth;
    icon?.classList.add('dock-bounce');
    icon?.addEventListener('animationend', () => icon.classList.remove('dock-bounce'), { once: true });
    scroll.scrollTop = 0;
    if (!alreadyNavigated) navigateDock(tab);
    return;
  }
  const route = tab === 'home' ? 'home' : tab === 'library' ? 'library' : tab === 'chigua' ? 'chigua' : tab === 'missav' ? 'missav' : 'category';
  const navigated = state.route !== route || state.tab !== tab;
  lastDockTap = { tab, at: now, navigated };
  if (navigated) navigateDock(tab);
}

document.addEventListener('click', async event => {
  const campaignButton = event.target.closest('[data-open-campaign]');
  if (campaignButton) {
    if (campaignButton.closest('.hero') && performance.now() < heroSuppressClickUntil) return;
    const item = activeCampaigns().find(item => item.id === campaignButton.dataset.openCampaign);
    if (item) goCampaign(item);
    return;
  }
  if (event.target.closest('[data-open-update]')) { if (updateAvailable) showUpdate(updateAvailable); else checkUpdate(true); return; }
  if (event.target.closest('[data-check-update]')) { checkUpdate(true); return; }
  if (event.target.closest('[data-check-resources]')) {
    const button = event.target.closest('[data-check-resources]');
    button.disabled = true;
    try {
      const result = await api('check-hot-update');
      window.hgHotUpdateStatus(result);
      toast(result.pending ? '资源已下载，返回首页空闲时会自动启用' : '已是最新资源');
    } catch (error) { toast(error.message, true); }
    finally { if (button.isConnected) button.disabled = false; }
    return;
  }
  if (event.target.closest('[data-apply-resources]')) { api('apply-hot-update').catch(error => toast(error.message, true)); return; }
  const nav = event.target.closest('[data-nav]');
  if (nav) { tapDock(nav); return; }
  const mvDelete = event.target.closest('[data-mv-history-delete]');
  if (mvDelete) {
    const id = mvDelete.dataset.mvHistoryDelete;
    try { localStorage.setItem(MISS_AV_HISTORY, JSON.stringify(missAvHistory().filter(item => item.id !== id))); } catch (error) { /* 仅本次生效 */ }
    if (state.route === 'library') renderLibrary();
    return;
  }
  if (event.target.closest('[data-mv-history-clear]')) {
    if (!await askConfirmation('清空仓库记录', '将删除本机保存的仓库观看记录。', '清空')) return;
    try { localStorage.removeItem(MISS_AV_HISTORY); } catch (error) { /* 仅本次生效 */ }
    if (state.route === 'library') renderLibrary();
    toast('仓库记录已清空');
    return;
  }
  const mvCat = event.target.closest('[data-mv-cat]');
  if (mvCat) { goMissAvList(mvCat.dataset.mvCat, mvCat.dataset.mvCatTitle || mvCat.textContent.trim(), 1, false); return; }
  const mvSearch = event.target.closest('[data-mv-search]');
  if (mvSearch) { goMissAvSearch(mvSearch.dataset.mvSearch); return; }
  if (event.target.closest('[data-mv-list-more]')) {
    const list = state.missavList;
    if (list) goMissAvList(list.id, list.title, list.page + 1, true);
    return;
  }
  if (event.target.closest('[data-mv-feed-more]')) {
    const feed = state.missavFeed;
    if (feed) goMissAvFeed(feed.page + 1, true);
    return;
  }
  const mvOpen = event.target.closest('[data-mv-open]');
  if (mvOpen) { goMissAvDetail(mvOpen.dataset.mvOpen, mvOpen.dataset.mvCover || ''); return; }
  const mvPlay = event.target.closest('[data-mv-play]');
  if (mvPlay) {
    const detail = state.missavDetail;
    if (detail?.stream && detail?.page) api('missav-play', { url: detail.stream, page: detail.page }).catch(error => toast(error.message || '播放失败', true));
    return;
  }
  if (event.target.closest('[data-mv-retry]')) { goMissAvHome(); return; }
  const libraryTab = event.target.closest('[data-library-tab]');
  if (libraryTab) { state.libraryTab = libraryTab.dataset.libraryTab; renderLibrary(); scroll.scrollTop = 0; return; }
  const historyCard = event.target.closest('[data-history-id]');
  if (historyCard) {
    const id = historyCard.dataset.historyId;
    if (historyCard.dataset.historyCompleted === 'true') goDetail(id, historyCard);
    // goDetail 在 token 失配时是静默 return，Promise 仍会 resolve；
    // 不校验的话，请求期间返回或改点别的剧，仍会弹出播放器甚至播错集。
    else goDetail(id).then(() => {
      if (state.route === 'detail' && state.detail?.id === id)
        openPlayer(Number(historyCard.dataset.historyEpisode || 1));
    });
    return;
  }
  if (event.target.closest('[data-all-tags]')) { goTags(); return; }
  const chiguaChannel = event.target.closest('[data-chigua-channel]');
  if (chiguaChannel) { goChigua(chiguaChannel.dataset.chiguaChannel); return; }
  if (event.target.closest('[data-chigua-more]')) {
    if (state.chigua?.nextPage && !state.chigua.loading) goChigua(state.chigua.channel, state.chigua.nextPage);
    return;
  }
  const chiguaPost = event.target.closest('[data-post-id]');
  if (chiguaPost) { goPost(chiguaPost.dataset.postId); return; }
  const topicCard = event.target.closest('[data-topic-slug]');
  if (topicCard) { goTopic(topicCard.dataset.topicSlug, topicCard.dataset.topicTitle); return; }
  const playPost = event.target.closest('[data-play-post]');
  if (playPost) {
    const post = state.post || {};
    api('play-post', {
      url: playPost.dataset.url, title: post.title || '', poster: playPost.dataset.poster || '',
      authKey: post.cdnAuthKey || '', authValue: post.cdnAuthValue || '', cdnApp: post.cdnApp || ''
    }).catch(error => toast(error.message || '视频无法播放', true));
    return;
  }
  const postImage = event.target.closest('img[data-view]');
  if (postImage) { openImageViewer(postImage.src); return; }
  if (event.target.closest('[data-post-bookmark]')) {
    const post = state.post;
    if (!post) return;
    const cover = asArray(post.videos)[0]?.poster || asArray(post.blocks).find(block => block.type === 'img')?.src || '';
    try {
      state.postBookmarked = await api('post-bookmark', {
        id: post.id, title: post.title, cover, author: post.author, date: post.date
      });
      toast(state.postBookmarked ? '已收藏到吃瓜收藏' : '已取消收藏');
      renderPost();
    } catch (error) { toast(error.message || '操作失败', true); }
    return;
  }
  const tagChoice = event.target.closest('[data-tag-slug]');
  if (tagChoice) { goTag(tagChoice.dataset.tagSlug, tagChoice.dataset.tagName); return; }
  const sub = event.target.closest('[data-sub]');
  if (sub) { goCategory(state.tab, Number(sub.dataset.sub), !!sub.closest('#compact-category')); return; }
  const card = event.target.closest('[data-open-id]');
  if (card?.dataset.openId) {
    if (card.closest('.hero') && performance.now() < heroSuppressClickUntil) return;
    goDetail(card.dataset.openId, card); return;
  }
  const filter = event.target.closest('[data-filter]');
  if (filter) { state.filter = filter.dataset.filter; renderSearch(); return; }
  const slide = event.target.closest('[data-slide]');
  if (slide) { const target = Number(slide.dataset.slide); changeBanner(target, target > state.banner ? 1 : -1); return; }
  if (event.target.closest('[data-back]')) { window.hgBack(); return; }
  const downloadEp = event.target.closest('[data-download-ep]');
  if (downloadEp) {
    if (!state.detail) return;
    try { state.downloads = await api('download-add', { id: state.detail.id, title: state.detail.title, cover: state.detail.cover, episodes: [Number(downloadEp.dataset.downloadEp)] }); refreshDownloadBadges(); toast('已加入下载'); }
    catch (error) { toast(error.message, true); }
    return;
  }
  if (event.target.closest('[data-download-all]')) {
    if (!state.detail) return;
    try { const list = asArray(state.detail.episodes).map(item => item.number); state.downloads = await api('download-add', { id: state.detail.id, title: state.detail.title, cover: state.detail.cover, episodes: list }); refreshDownloadBadges(); toast(`已加入 ${list.length} 集下载队列，按顺序下载`); }
    catch (error) { toast(error.message, true); }
    return;
  }
  const downloadPlay = event.target.closest('[data-download-play]');
  if (downloadPlay) {
    const id = downloadPlay.dataset.downloadId;
    const episode = Number(downloadPlay.dataset.downloadEpisode);
    const done = asArray(state.downloads?.items).filter(item => item.id === id && item.status === 'done');
    const episodes = done.map(item => ({ number: Number(item.episode) })).sort((a, b) => a.number - b.number);
    try { await api('play-download', { id, episode, title: done[0]?.title || '', cover: done[0]?.cover || '', episodes }); }
    catch (error) { toast(error.message, true); }
    return;
  }
  const downloadSelect = event.target.closest('[data-download-select]');
  if (downloadSelect) {
    state.downloadSelect = { id: downloadSelect.dataset.downloadSelect, keys: [] };
    renderLibrary();
    return;
  }
  const selectKey = event.target.closest('[data-select-key]');
  if (selectKey) {
    const selection = state.downloadSelect;
    if (!selection) return;
    const key = selectKey.dataset.selectKey;
    const index = selection.keys.indexOf(key);
    if (index >= 0) selection.keys.splice(index, 1); else selection.keys.push(key);
    renderLibrary();
    return;
  }
  if (event.target.closest('[data-select-cancel]')) {
    state.downloadSelect = null;
    renderLibrary();
    return;
  }
  const exportSelected = event.target.closest('[data-export-selected]') || event.target.closest('[data-export-merge]');
  if (exportSelected) {
    const selection = state.downloadSelect;
    if (!selection) return;
    const merge = exportSelected.hasAttribute('data-export-merge');
    const group = asArray(state.downloads?.items).filter(item => item.id === selection.id);
    const episodes = group.filter(item => selection.keys.includes(item.key) && item.status === 'done')
      .map(item => Number(item.episode)).sort((a, b) => a - b);
    if (!episodes.length) { toast('请选择已下载完成的集', true); return; }
    if (merge && episodes.length < 2) { toast('合并导出至少选择 2 集', true); return; }
    try {
      state.downloads = await api('export-download', {
        id: selection.id, title: group[0]?.title || '', episodes, merge
      });
      state.downloadSelect = null;
      renderLibrary();
      toast(merge ? `开始合并导出 ${episodes.length} 集` : `开始导出 ${episodes.length} 集`);
    } catch (error) { toast(error.message || '导出失败', true); }
    return;
  }
  const deleteSelected = event.target.closest('[data-delete-selected]');
  if (deleteSelected) {
    const selection = state.downloadSelect;
    if (!selection?.keys.length) return;
    if (!await askConfirmation('删除选中的下载', `将删除 ${selection.keys.length} 集的本地下载，已导出的 MP4 不受影响。`, '删除')) return;
    try {
      state.downloads = await api('download-remove', { keys: selection.keys });
      state.downloadSelect = null;
      renderLibrary();
      toast('已删除');
    } catch (error) { toast(error.message || '删除失败', true); }
    return;
  }
  const downloadRetry = event.target.closest('[data-download-retry]');
  if (downloadRetry) {
    try { state.downloads = await api('download-retry', { key: downloadRetry.dataset.downloadRetry }); renderLibrary(); }
    catch (error) { toast(error.message, true); }
    return;
  }
  const downloadExpand = event.target.closest('[data-download-expand]');
  if (downloadExpand) {
    state.downloadExpanded = state.downloadExpanded || {};
    state.downloadExpanded[downloadExpand.dataset.downloadExpand] = true;
    renderLibrary();
    return;
  }
  const downloadExport = event.target.closest('[data-download-export]');
  if (downloadExport) {
    try {
      await api('export-download', { id: downloadExport.dataset.downloadExport, title: downloadExport.dataset.downloadExportTitle });
      toast('开始导出，完成前请保持 App 在前台');
    } catch (error) { toast(error.message, true); }
    return;
  }
  const downloadGroup = event.target.closest('[data-download-remove-group]');
  if (downloadGroup) {
    const keys = asArray(state.downloads?.items).filter(item => item.id === downloadGroup.dataset.downloadRemoveGroup).map(item => item.key);
    try { state.downloads = await api('download-remove', { keys }); renderLibrary(); toast('已删除'); }
    catch (error) { toast(error.message, true); }
    return;
  }
  const episode = event.target.closest('[data-episode]');
  if (episode) { openPlayer(Number(episode.dataset.episode)); return; }
  if (event.target.closest('[data-play]')) { openPlayer(1); return; }
  if (event.target.closest('[data-bookmark]')) {
    if (!state.detail) return;
    const id = state.detail.id;
    try { applyBookmarkState(await api('bookmark', state.detail), id); toast(state.bookmarked ? '已加入我的片单' : '已取消收藏'); }
    catch (error) { toast(error.message, true); }
    return;
  }
  if (event.target.closest('[data-retry-category]')) { state.category.error = false; loadMoreCategory(); return; }
  const more = event.target.closest('[data-more]');
  if (more) { openListing(more.dataset.more); return; }
  if (event.target.closest('[data-retry-listing]')) { state.listing.error = false; loadMoreListing(); return; }
  const retry = event.target.closest('[data-retry]');
  if (retry) {
    if (retry.dataset.retry === 'home') goHome();
    else if (retry.dataset.retry === 'category') goCategory(state.tab);
    else if (retry.dataset.retry === 'library') goLibrary();
    else if (retry.dataset.retry === 'search') goSearch(state.query);
    else if (retry.dataset.retry === 'listing') openListing(state.listing.kind);
    else if (retry.dataset.retry === 'tags') goTags();
    else if (retry.dataset.retry === 'tag-list') goTag(state.listing.slug, state.listing.label);
    else if (retry.dataset.retry === 'detail') goDetail(state.sourceItem.id);
    else if (retry.dataset.retry === 'chigua') goChigua(state.chigua?.channel || 'all');
    else if (retry.dataset.retry === 'post') goPost(state.postId);
    else if (retry.dataset.retry === 'topic') goTopic(state.topicSlug, state.topic?.title);
    return;
  }
  const accentSet = event.target.closest('[data-accent-set]');
  if (accentSet) {
    try { localStorage.setItem('hg-accent', accentSet.dataset.accentSet); } catch (error) { /* 仅本次生效 */ }
    applyPalette('custom');
    renderSettings();
    return;
  }
  const customMode = event.target.closest('[data-custom-mode]');
  if (customMode) {
    try { localStorage.setItem('hg-custom-mode', customMode.dataset.customMode); } catch (error) { /* 仅本次生效 */ }
    applyPalette('custom');
    renderSettings();
    return;
  }
  const palettePick = event.target.closest('[data-palette-pick]');
  if (palettePick) {
    const id = palettePick.dataset.palettePick;
    if (PALETTES.some(item => item.id === id)) {
      try { localStorage.setItem('hg-palette', id); } catch (error) { /* 无 localStorage 时仅本次生效 */ }
      applyPalette(id);
      renderSettings();
    }
    return;
  }
  const clear = event.target.closest('[data-clear]');
  if (clear) {
    if (clear.dataset.clear === 'cache') {
      if (!await askConfirmation('清理内容缓存', '将删除已缓存的目录和封面。收藏与观看进度会保留。', '清理')) return;
      await api('clear-content-cache'); toast('内容缓存已清空');
    } else if (clear.dataset.clear === 'history' || clear.dataset.clear === 'bookmarks') {
      const history = clear.dataset.clear === 'history';
      if (!await askConfirmation(history ? '清空观看历史' : '清空我的收藏', history ? '所有观看记录会被删除，我的收藏会保留。' : '所有收藏作品会被移除，观看历史会保留。')) return;
      await api(history ? 'clear-history' : 'clear-bookmarks');
      state.library = await api('library');
      renderSettings();
      toast(history ? '观看历史已清空' : '收藏已清空');
    }
  }
});

document.addEventListener('input', event => {
  const picker = event.target.closest('[data-accent-picker]');
  if (!picker) return;
  try { localStorage.setItem('hg-accent', picker.value); } catch (error) { /* 仅本次生效 */ }
  applyPalette('custom');
});

let heroTouch;
let heroSuppressClickUntil = 0;
content.addEventListener('touchstart', event => {
  if (!event.target.closest('.hero') || event.touches.length !== 1) return;
  stopBannerAuto();
  const touch = event.touches[0];
  heroTouch = { x: touch.clientX, y: touch.clientY, moved: false };
}, { passive: true });
content.addEventListener('touchmove', event => {
  if (!heroTouch || !event.touches.length) return;
  const touch = event.touches[0];
  heroTouch.moved ||= Math.abs(touch.clientX - heroTouch.x) > 10 || Math.abs(touch.clientY - heroTouch.y) > 10;
}, { passive: true });
content.addEventListener('touchend', event => {
  if (!heroTouch) return;
  const touch = event.changedTouches[0];
  const move = touch.clientX - heroTouch.x;
  const vertical = touch.clientY - heroTouch.y;
  if (heroTouch.moved || Math.abs(move) > 10 || Math.abs(vertical) > 10) heroSuppressClickUntil = performance.now() + 400;
  heroTouch = null;
  scheduleBannerAuto();
  if (Math.abs(move) < 55 || Math.abs(move) <= Math.abs(vertical) || !state.home) return;
  const count = homeSlides().length;
  if (!count) return;
  const direction = move < 0 ? 1 : -1;
  changeBanner((state.banner + direction + count) % count, direction);
}, { passive: true });
content.addEventListener('touchcancel', () => {
  if (!heroTouch) return;
  heroTouch = null; heroSuppressClickUntil = performance.now() + 400;
  scheduleBannerAuto();
}, { passive: true });

api('app-version').then(version => {
  appVersion = String(version || '');
  const label = content.querySelector('.app-version-text');
  if (label) label.textContent = `版本 v${appVersion}`;
  setAvailableUpdate(updateAvailable);
}).catch(() => {});
api('cached-update').then(result => { if (result.status === 'available') setAvailableUpdate(result); }).catch(() => {});
function startHome() { goHome(); setTimeout(() => checkUpdate(false), 3000); }
document.getElementById('age-confirm').addEventListener('click', () => { localStorage.setItem('adult-confirmed', '1'); api('confirm-age').catch(() => {}); document.getElementById('age-gate').hidden = true; startHome(); });
document.getElementById('age-exit').addEventListener('click', () => api('quit'));
api('age-status').then(confirmed => {
  if (confirmed || localStorage.getItem('adult-confirmed') === '1') {
    document.getElementById('age-gate').hidden = true;
    startHome();
  } else document.getElementById('age-gate').hidden = false;
}).catch(() => { if (localStorage.getItem('adult-confirmed') === '1') startHome(); else document.getElementById('age-gate').hidden = false; });

let pendingResourceRevision = 0;
let resourceApplyTimer = null;
let resourceApplyRequested = false;
let lastResourceInteraction = performance.now();
const resourceIdleMs = 3000;
window.hgCanApplyHotUpdate = () => ['home', 'settings'].includes(state.route)
  && !document.hidden && document.hasFocus()
  && (state.route !== 'home' || scroll.scrollTop <= 4)
  && confirmOverlay.hidden && updateOverlay.hidden
  && document.getElementById('age-gate').hidden
  && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)
  && !bannerChanging && !heroTouch && !predictivePreview && !predictiveFrame
  && !document.getElementById('app').classList.contains('card-transition-active')
  && !document.getElementById('app').classList.contains('predictive-active');
function scheduleResourceApply(delay) {
  if (resourceApplyRequested) return;
  clearTimeout(resourceApplyTimer);
  resourceApplyTimer = null;
  if (!pendingResourceRevision || resourceApplyRequested || document.hidden || !document.hasFocus()) return;
  resourceApplyTimer = setTimeout(tryApplyResources, delay ?? Math.max(150,
    resourceIdleMs - (performance.now() - lastResourceInteraction)));
}
function tryApplyResources() {
  resourceApplyTimer = null;
  if (!pendingResourceRevision || resourceApplyRequested) return;
  if (state.route !== 'home' || !window.hgCanApplyHotUpdate()
      || !content.querySelector('.home-page,.error-state')
      || performance.now() - lastResourceInteraction < resourceIdleMs) {
    scheduleResourceApply(750);
    return;
  }
  resourceApplyRequested = true;
  api('apply-hot-update').catch(() => {});
  // A gesture can start between the JS idle check and the native check. Retry
  // only if this document remains alive; a successful activation replaces it.
  resourceApplyTimer = setTimeout(() => {
    resourceApplyRequested = false;
    window.hgRefreshPendingResources();
  }, 2000);
}
window.hgScheduleResourceApply = () => { lastResourceInteraction = performance.now(); scheduleResourceApply(); };
window.hgRefreshPendingResources = () => {
  if (!document.hidden && document.hasFocus()) api('hot-update-status').then(window.hgHotUpdateStatus).catch(() => {});
};
window.hgHotUpdateStatus = result => {
  const label = content.querySelector('[data-resource-status]');
  if (label) label.textContent = result.pending ? '资源已下载，首页空闲时自动启用。' : '当前资源：' + (result.version || '内置') + '，后台自动更新。';
  const apply = content.querySelector('[data-apply-resources]');
  if (apply) apply.hidden = !result.pending;
  pendingResourceRevision = Number(result.pending) > Number(window.HotRuntime?.revision || 0) ? Number(result.pending) : 0;
  if (!pendingResourceRevision) resourceApplyRequested = false;
  scheduleResourceApply();
};
function resourceInteraction() {
  lastResourceInteraction = performance.now();
  if (!resourceApplyRequested) scheduleResourceApply();
}
for (const type of ['pointerdown', 'pointermove', 'pointerup', 'keydown', 'input', 'focusin', 'focusout', 'wheel'])
  document.addEventListener(type, resourceInteraction, { capture: true, passive: true });
document.addEventListener('scroll', resourceInteraction, { capture: true, passive: true });
window.addEventListener('blur', () => { clearTimeout(resourceApplyTimer); resourceApplyTimer = null; resourceApplyRequested = false; });
window.addEventListener('focus', () => { resourceInteraction(); window.hgRefreshPendingResources(); });
document.addEventListener('visibilitychange', () => {
  clearTimeout(resourceApplyTimer); resourceApplyTimer = null; resourceApplyRequested = false;
  if (!document.hidden) { resourceInteraction(); window.hgRefreshPendingResources(); }
});
api('hot-update-status').then(window.hgHotUpdateStatus).catch(() => {});
window.hgBootReady?.();
